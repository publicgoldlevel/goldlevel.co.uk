# SAFETY REVIEW CHECKLIST

## Defensive release gate

Pass only if all required gates are satisfied.

- [ ] Defensive intent is explicit.
- [ ] Public education value is clear.
- [ ] Lab or data source is controlled, sanitized, or clearly bounded.
- [ ] No live malware binaries are included.
- [ ] No victim data is included.
- [ ] No credential material is included.
- [ ] No operational exploit chain is included.
- [ ] No evasion bypass details are included.
- [ ] No unauthorized targeting is included.
- [ ] Limitations are declared.
- [ ] Reviewer notes are included.

## Misuse-risk triage

| Question | Action |
|---|---|
| Could this enable harm if copied directly? | Abstract, redact, or hold. |
| Can detection value be preserved without weaponization? | Keep defensive signal; remove operational detail. |
| Does it help defenders more than attackers? | If unclear, hold for review. |
| Are claims stronger than evidence? | Downgrade claim or add evidence. |
| Is sensitive data present? | Remove before submission. |

## Publication decision

- [ ] Approve
- [ ] Approve after edits
- [ ] Hold for safety review
- [ ] Reject / unsafe for public release

## Minimal helper

If uncertain, default to:

> Preserve the defensive lesson. Remove the operational harm path.


## Protected Safety Feature Review

Confirm that this submission and any derivative artifact preserve all protected safety features.

```text
[ ] Defensive-use boundary remains present and visible.
[ ] Prohibited-content categories remain specific.
[ ] Safety review remains mandatory.
[ ] Evidence/reproducibility review remains mandatory.
[ ] Release readiness gate remains mandatory.
[ ] Reviewer may hold or reject unsafe submissions.
[ ] Claim-evidence-limit structure remains present where relevant.
[ ] Unsafe operational paths are removed, sanitized, abstracted, or held.
[ ] Sanitized examples remain sanitized.
[ ] Draft status is not misrepresented as external validation.
[ ] No automated summary has removed safety gates.
```

If any item fails:

```text
PUBLIC_RELEASE_BLOCKED
REVISE_OR_HOLD_FOR_REVIEW
```
