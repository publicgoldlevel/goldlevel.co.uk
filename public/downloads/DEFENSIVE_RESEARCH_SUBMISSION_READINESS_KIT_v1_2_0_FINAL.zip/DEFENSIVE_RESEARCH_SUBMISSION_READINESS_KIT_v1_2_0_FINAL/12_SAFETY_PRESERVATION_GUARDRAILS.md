# Safety Preservation Guardrails

Safety controls in this kit are protected controls.

They may be clarified, expanded, reorganized, or made easier to enforce.

They may not be removed, weakened, hidden, bypassed, or converted into optional suggestions.

## Protected Controls

- defensive-use boundary
- prohibited-content categories
- safety review checklist
- evidence and reproducibility checklist
- release readiness rubric
- contributor review rubric
- claim-evidence-limit structure
- publication threshold
- sanitized examples
- reviewer hold/reject authority
- proof boundary
- fail-closed release default

## Release Rule

```text
IF protected safety controls are missing or weaker than prior version:
    PUBLIC_RELEASE_BLOCKED
    RRL=RRL-1_LOCAL_DRAFT_ONLY
    SAFETY_REVIEW_REQUIRED
```

## Default

```text
If unclear, do not publish publicly.
Sanitize, abstract, or hold for review.
```
