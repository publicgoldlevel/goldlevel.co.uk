# GITHUB REPOSITORY READINESS CHECKLIST

## Required files

- [ ] README.md
- [ ] LICENSE
- [ ] CHANGELOG.md
- [ ] SECURITY.md
- [ ] CONTRIBUTING.md
- [ ] docs/
- [ ] examples/
- [ ] tests/
- [ ] references/

## README minimum

Your README should include:

- what the project does
- who it is for
- defensive purpose
- safe installation instructions
- safe usage examples
- limitations
- safety boundary
- how to contribute
- license

## Safe repository types

- YARA rules
- Sigma rules
- Suricata / Snort rules
- IOC parsers
- log enrichment utilities
- malware-analysis note templates
- sandbox report parsers
- defensive dashboards
- triage helpers
- educational toy examples that cannot be weaponized

## Blocked repository types

- live malware binaries
- credential theft tools
- persistence or evasion payloads
- working exploit chains against real targets
- ransomware logic
- active C2 frameworks
- unauthorized scanning or exploitation automation

## Release helper

A repo is release-ready only when:

- [ ] examples are safe
- [ ] tests pass
- [ ] license is present
- [ ] no secrets are present
- [ ] no victim data is present
- [ ] README explains defensive use
- [ ] SECURITY.md explains reporting
- [ ] dangerous details are removed or abstracted


## Safety Preservation Gate

Before release, confirm:

```text
[ ] The repository does not include live malware or unsafe payloads.
[ ] The repository does not include weaponized exploit chains.
[ ] The repository does not include credential theft tooling or guidance.
[ ] The repository does not include evasion or bypass guidance.
[ ] The repository does not include unauthorized targeting instructions.
[ ] The repository does not include victim data.
[ ] Safety notes are visible in README or release notes.
[ ] Defensive use is explicit.
[ ] Unsafe operational paths have been removed, sanitized, or abstracted.
[ ] Reviewer hold/reject authority remains intact.
```

If any item fails, do not publish the repository publicly.
