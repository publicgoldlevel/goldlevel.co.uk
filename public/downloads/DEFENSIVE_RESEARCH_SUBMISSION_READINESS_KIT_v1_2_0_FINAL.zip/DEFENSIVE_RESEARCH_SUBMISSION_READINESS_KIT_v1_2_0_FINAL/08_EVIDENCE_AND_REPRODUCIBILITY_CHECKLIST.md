# EVIDENCE AND REPRODUCIBILITY CHECKLIST

## Claim-evidence-limit pattern

For every major claim, fill this:

```text
Claim:
Evidence:
Method:
Limit:
Defensive relevance:
```

## Required evidence fields

- [ ] Lab environment described.
- [ ] Tools or data sources listed.
- [ ] Methods are explained.
- [ ] Findings are supported.
- [ ] Limitations are visible.
- [ ] References are included.
- [ ] Uncertainty is not hidden.
- [ ] External validation is not claimed without receipts.

## Reproducibility level

| Level | Meaning |
|---|---|
| R0 | No reproducibility; notes only. |
| R1 | Method described, but not independently repeatable. |
| R2 | Controlled lab notes and enough detail for safe internal repetition. |
| R3 | Safe artifacts included; reviewer can validate. |
| R4 | Published artifacts are tested or cited. |
| R5 | Method is maintained and repeatable across cases. |

## Minimal helper

If you cannot reproduce the work safely, say so. Do not inflate confidence.


## Evidence / Safety Coupling

Evidence and reproducibility must not become misuse enablement.

Reproducibility means:

```text
A reviewer can understand and evaluate the claim safely.
```

Reproducibility does not mean:

```text
A public reader receives everything needed to reproduce harm.
```

Check:

```text
[ ] The evidence supports the claim.
[ ] The method is understandable without enabling misuse.
[ ] The limitations are explicit.
[ ] Unsafe replication detail is removed or abstracted.
[ ] Sensitive artifacts are replaced with sanitized indicators, summaries, diagrams, or synthetic examples.
[ ] The submission does not confuse transparency with unsafe disclosure.
```
