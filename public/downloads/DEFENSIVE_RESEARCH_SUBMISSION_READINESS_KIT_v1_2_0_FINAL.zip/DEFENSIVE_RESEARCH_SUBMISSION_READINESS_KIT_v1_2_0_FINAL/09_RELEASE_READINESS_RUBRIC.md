# RELEASE READINESS RUBRIC

Use RRL externally instead of internal O-Seal language.

| Level | Name | Meaning | Public status |
|---|---|---|---|
| RRL-0 | Unverified Note | Idea exists but is not packaged or reviewed. | Do not publish. |
| RRL-1 | Local Draft | Work exists locally but is incomplete or unreviewed. | Not submission-ready. |
| RRL-2 | Review-Ready Submission | Structured, bounded, and safe enough for editorial/security review. | Submit for review. |
| RRL-3 | Community-Published Artifact | Published or shared in a controlled public channel. | Public artifact. |
| RRL-4 | Defender-Useful Artifact | Evidence of utility, testing, adoption, citations, or feedback. | Validated usefulness. |
| RRL-5 | Repeatable Research Pattern | Reusable, maintained, validated workflow. | Mature pattern. |

## Fast scoring

Score each 0-2.

- Defensive value:
- Evidence quality:
- Safety boundary:
- Reproducibility:
- Clarity:
- Maintenance readiness:

Total:
- 0-4: RRL-0/1
- 5-8: RRL-1
- 9-10: RRL-2
- 11-12: RRL-3 candidate after review

## Minimal helper

Do not call something published, validated, adopted, or repeatable until there is an external receipt.


## Safety Preservation Downgrade Rule

A submission or kit version cannot advance readiness level if protected safety features are missing or weakened.

Automatic downgrade:

```text
IF protected safety feature removed OR weakened:
    SET RELEASE_READINESS_LEVEL=RRL-1_LOCAL_DRAFT_ONLY
    SET PUBLIC_RELEASE=BLOCKED
    SET REQUIRED_ACTION=SAFETY_REVIEW
```

Readiness cannot exceed RRL-1 if:

- safety boundary is missing;
- prohibited-content categories are vague or absent;
- review authority is removed;
- unsafe content is allowed through warning-only language;
- evidence requirements are removed;
- examples are not sanitized;
- derivative work omits safety controls.

RRL-2 or higher requires:

```text
ALL_PROTECTED_SAFETY_FEATURES_PRESENT_VISIBLE_ENFORCEABLE_NO_WEAKER_THAN_PRIOR_VERSION
```
