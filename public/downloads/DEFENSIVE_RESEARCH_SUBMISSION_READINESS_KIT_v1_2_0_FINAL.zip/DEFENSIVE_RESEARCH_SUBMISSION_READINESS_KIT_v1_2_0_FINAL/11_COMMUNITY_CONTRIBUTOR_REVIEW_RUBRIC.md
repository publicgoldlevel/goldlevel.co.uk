# COMMUNITY CONTRIBUTOR REVIEW RUBRIC

## Reviewer role

The reviewer helps determine whether a submission is:

- useful
- safe
- clear
- evidence-backed
- publication-ready
- aligned with defensive research goals

## Review dimensions

| Dimension | Pass condition |
|---|---|
| Defensive purpose | The work clearly helps defenders, analysts, educators, or learners. |
| Safety | No live malware, weaponized code, credentials, victim data, evasion guidance, or unauthorized targeting. |
| Evidence | Claims are supported by methods, observations, or references. |
| Reproducibility | A safe reviewer can understand or repeat the method where appropriate. |
| Clarity | The submission is readable and not overclaimed. |
| Community value | The work teaches, detects, explains, or improves defensive practice. |
| Maintenance | If code/rules are included, versioning and update path are visible. |

## Review outcome

- Accept
- Accept with minor edits
- Revise and resubmit
- Hold for safety review
- Decline

## Reviewer note helper

Use this structure:

```text
Decision:
Strongest value:
Main risk:
Required edits:
Suggested readiness level:
```


## Safety Preservation Review

Reviewer decision must include:

```text
Protected safety features present? yes / no
Safety weakened from prior version? yes / no
Unsafe operational path present? yes / no
Evidence sufficient without enabling harm? yes / no
Public release allowed? yes / no
Required safety edits:
Final decision:
```

Reviewer decision rule:

```text
IF safety weakened OR unsafe operational path present:
    DECISION=HOLD_OR_REJECT
ELSE IF evidence insufficient:
    DECISION=REVISE
ELSE:
    DECISION=ALLOW_NEXT_READINESS_REVIEW
```

The reviewer may not approve public release by replacing required safety controls with a warning label.
