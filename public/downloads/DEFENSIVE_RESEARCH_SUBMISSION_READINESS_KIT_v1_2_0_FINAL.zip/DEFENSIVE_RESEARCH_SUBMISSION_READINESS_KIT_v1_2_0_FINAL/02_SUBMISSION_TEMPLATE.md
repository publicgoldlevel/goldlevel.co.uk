# SUBMISSION TEMPLATE

## 1. 90-second contribution block

**Title:**  
**Category:** research paper / article / GitHub repository / video / detection package / educational tool

**One-sentence value:**  
This work helps defenders by showing ______, using ______ evidence, within ______ limits, so that ______ can be detected, understood, or taught safely.

**Audience:** beginner / intermediate / advanced / researcher

**Defensive value:**  
- What can defenders learn or use?
- What risk does it help identify, explain, detect, or reduce?

**Safety boundary:**  
This submission does not include live malware, weaponized exploit code, credentials, victim data, unauthorized targeting, operational attack chains, or evasion guidance.

## 2. Lane selector

Select one primary lane:

| Lane | Choose this when | Required output |
|---|---|---|
| Research paper | You have original analysis, methodology, or findings. | Abstract, methods, evidence, findings, limitations, references. |
| Article / tutorial | You are teaching a concept or workflow. | Learning objective, safe walkthrough, defensive takeaways. |
| GitHub repository | You have code, detections, parsers, or reusable files. | README, license, safe examples, tests, docs, security notes. |
| Video / presentation | You are explaining research visually. | Outline, transcript/notes, screenshots, safety disclaimer. |
| Detection package | You have rules or indicators. | Rule files, test notes, false-positive notes, mitigation relevance. |

## 3. Submission summary

### Abstract

Write 150-300 words.

### Scope

In scope:
- 

Out of scope:
- 

### Methods

- Lab or data source:
- Tools used:
- Analysis method:
- Constraints:

### Findings

1. 
2. 
3. 

### Defensive outputs

- Indicators:
- Detection rules:
- Mitigations:
- Triage notes:
- References:

### Limitations

- What is not proven?
- What requires more validation?
- What should not be inferred?

## 4. Reviewer notes

The reviewer should check:

- safety boundary
- evidence support
- claim strength
- reproducibility
- educational value
- misuse risk
- publication readiness


## Safety Preservation Confirmation

Before submission, confirm:

```text
[ ] I did not remove or weaken the defensive-use boundary.
[ ] I did not include live malware, weaponized exploit chains, credential theft, evasion guidance, unauthorized targeting, or victim data.
[ ] I preserved the safety review requirement.
[ ] I preserved the evidence and reproducibility requirement.
[ ] I identified any operational harm path and removed, sanitized, or abstracted it.
[ ] I understand that unclear safety status means hold for review, not public release.
```

If any box cannot be checked, the submission is not ready for public release.
