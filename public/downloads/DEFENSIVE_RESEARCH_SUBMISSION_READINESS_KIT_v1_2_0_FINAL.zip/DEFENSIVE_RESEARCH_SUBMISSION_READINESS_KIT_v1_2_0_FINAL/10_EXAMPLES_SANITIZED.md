# SANITIZED EXAMPLES

## Example 1 — Research paper lane

**Title:** Behavioral Summary of a Suspicious Loader Pattern in a Controlled Lab

**Category:** research_paper

**One-sentence value:**  
This work helps defenders understand a recurring loader-like behavior pattern using sanitized lab observations within a controlled VM, so that analysts can recognize related telemetry safely.

**Defensive value:**  
The paper identifies observable behaviors, logging points, and mitigation considerations without distributing live payloads or operational attack steps.

**Evidence:**  
- controlled VM notes
- screenshots with sensitive details removed
- hash-only sample reference
- process tree description
- file and registry behavior summarized at a defensive level

**Limitations:**  
The analysis does not claim attribution, full malware-family classification, or external prevalence.

**Readiness:** RRL-2 if reviewed and safety gate passes.

---

## Example 2 — GitHub lane

**Title:** Sigma Rules for Suspicious Script Interpreter Chains

**Category:** detection_package / github_repository

**One-sentence value:**  
This project helps defenders detect suspicious interpreter behavior using Sigma rules, test logs, and false-positive notes.

**Safe contents:**  
- Sigma rules
- synthetic logs
- README
- false-positive guidance
- references
- no exploit code
- no live malware
- no victim data

**Readiness:** RRL-2 before publication; RRL-3 after controlled public release.

---

## Example 3 — Article lane

**Title:** How to Document Malware Analysis Without Publishing Harmful Material

**Category:** article

**One-sentence value:**  
This article helps learners write safer malware-analysis notes by separating defensive observations from operationally harmful details.

**Defensive takeaway:**  
Preserve indicators, behavior, mitigations, and lessons; remove payloads, exploit chains, credentials, evasion steps, and victim details.


## Sanitized Example Preservation Rule

Examples must remain sanitized.

Examples may show:

- defensive framing;
- safe claim structure;
- sanitized evidence summaries;
- abstracted diagrams;
- detection or prevention concepts;
- safe limitations;
- review decisions.

Examples must not show:

- live malware;
- weaponized exploit chains;
- credential theft workflows;
- evasion steps;
- unauthorized targeting;
- victim data;
- operational replication paths.

If an example becomes operationally unsafe, remove, sanitize, abstract, or hold it for review.
