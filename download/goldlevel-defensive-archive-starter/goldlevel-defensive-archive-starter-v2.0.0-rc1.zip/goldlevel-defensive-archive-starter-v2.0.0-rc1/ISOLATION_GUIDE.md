# Isolation guide

The included programs do not create an operating-system sandbox. Run them with
the least privilege available.

Recommended conditions:

- use a non-administrator account;
- keep the source read-only;
- keep output on a separate writable path;
- disable network access for local-folder capture;
- do not mount credential stores, SSH directories, browser profiles, or cloud
  configuration into the review environment;
- verify before optional extraction;
- extract only into a new empty directory;
- do not restore captured objects into a production path;
- do not rename extensionless objects to executable extensions;
- keep release signature material read-only and pin the public key independently.

A container, virtual machine, disposable user account, or dedicated review
device can add isolation. The choice and security of that environment remain
outside this archive.
---

**Product:** GOLDLEVEL Defensive Archive Starter  
**Publisher:** GOLDLEVEL (Gold Level)  
**Version:** 2.0.0-rc1  
**Licence:** MIT  
**Copyright:** Copyright (c) 2026 GOLDLEVEL  
**Canonical route:** https://goldlevel.co.uk/download/goldlevel-defensive-archive-starter/  
**Artifact role:** ISOLATION_GUIDE  
**Audience:** PUBLIC  
**Release state:** HARDENED_FULL_SPECTRUM_REVIEW_CANDIDATE

