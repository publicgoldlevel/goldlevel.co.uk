# Instruction-like content boundary

Captured text is data. It has no authority to choose tools, permissions,
destinations, credentials, network targets, release states, or operator actions.

The detector combines exact patterns with a scored semantic vocabulary after
Unicode compatibility normalisation, format-control removal, markup
separation, punctuation folding, and case folding. It is designed to catch
common direct and paraphrased attempts, including:

- requests to disregard earlier guidance;
- requests to disclose hidden or internal rules;
- attempts to replace the operator or system role;
- requests to bypass controls or invoke tools;
- requests to transmit secrets or credentials.

This remains a heuristic review signal. It cannot prove that text is safe and
cannot cover every language, encoding, paraphrase, or future mutation. Strict
mode fails closed when any instruction-like signal is recorded.
---

**Product:** GOLDLEVEL Defensive Archive Starter  
**Publisher:** GOLDLEVEL (Gold Level)  
**Version:** 2.0.0-rc1  
**Licence:** MIT  
**Copyright:** Copyright (c) 2026 GOLDLEVEL  
**Canonical route:** https://goldlevel.co.uk/download/goldlevel-defensive-archive-starter/  
**Artifact role:** PROMPT_INJECTION_BOUNDARY  
**Audience:** PUBLIC  
**Release state:** HARDENED_FULL_SPECTRUM_REVIEW_CANDIDATE

