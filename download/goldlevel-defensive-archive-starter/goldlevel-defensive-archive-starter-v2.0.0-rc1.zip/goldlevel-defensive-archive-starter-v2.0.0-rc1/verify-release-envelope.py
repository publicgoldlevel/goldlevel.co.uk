#!/usr/bin/env python3
# Product: GOLDLEVEL Defensive Archive Starter
# Publisher: GOLDLEVEL
# Version: 2.0.0-rc1
# Licence: MIT
# Copyright: Copyright (c) 2026 GOLDLEVEL
# Canonical route: https://goldlevel.co.uk/download/goldlevel-defensive-archive-starter/
# Release state: HARDENED_FULL_SPECTRUM_REVIEW_CANDIDATE
"""Verify the complete GOLDLEVEL release envelope without extracting it."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import stat
import subprocess
import sys
import unicodedata
import zipfile
from pathlib import Path, PurePosixPath

EXPECTED_PRODUCT = 'GOLDLEVEL Defensive Archive Starter'
EXPECTED_PUBLISHER = 'GOLDLEVEL'
EXPECTED_VERSION = '2.0.0-rc1'
EXPECTED_LICENSE = 'MIT'
EXPECTED_COPYRIGHT = 'Copyright (c) 2026 GOLDLEVEL'
EXPECTED_ROUTE = 'https://goldlevel.co.uk/download/goldlevel-defensive-archive-starter/'
EXPECTED_ROOT = 'goldlevel-defensive-archive-starter-v2.0.0-rc1'
FIXED_TIME = (1980, 1, 1, 0, 0, 0)


class Hold(RuntimeError):
    pass


def digest(path: Path, algorithm: str) -> str:
    value = hashlib.new(algorithm)
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def read_sidecar(path: Path, algorithm: str, expected_filename: str) -> str:
    line = path.read_text(encoding="utf-8").strip()
    try:
        value, filename = line.split("  ", 1)
    except ValueError as exc:
        raise Hold(f"malformed {algorithm} sidecar") from exc
    expected_length = 64 if algorithm == "sha256" else 128
    if not re.fullmatch(rf"[0-9a-f]{{{expected_length}}}", value):
        raise Hold(f"invalid {algorithm} digest")
    if filename != expected_filename:
        raise Hold(
            f"{algorithm} sidecar filename mismatch: "
            f"{filename!r} != {expected_filename!r}"
        )
    return value


def safe_name(raw: object) -> str:
    if not isinstance(raw, str) or not raw or "\\" in raw or "\x00" in raw:
        raise Hold(f"unsafe ZIP path: {raw!r}")
    path = PurePosixPath(raw)
    if path.is_absolute() or any(part in {"", ".", ".."} for part in path.parts):
        raise Hold(f"unsafe ZIP path: {raw!r}")
    normal = unicodedata.normalize("NFC", path.as_posix())
    if normal != path.as_posix():
        raise Hold(f"non-canonical ZIP path: {raw!r}")
    return normal


def key_fingerprint(public_key: Path) -> str:
    openssl = shutil.which("openssl")
    if not openssl:
        raise Hold(
            "OpenSSL unavailable; signature verification requires local proof"
        )
    process = subprocess.run(
        [openssl, "pkey", "-pubin", "-in", str(public_key), "-outform", "DER"],
        check=False,
        capture_output=True,
    )
    if process.returncode != 0:
        raise Hold(
            "unable to derive public-key fingerprint: "
            + process.stderr.decode("utf-8", errors="replace")
        )
    return hashlib.sha256(process.stdout).hexdigest()


def verify_signature(payload: Path, signature: Path, public_key: Path) -> None:
    openssl = shutil.which("openssl")
    if not openssl:
        raise Hold(
            "OpenSSL unavailable; signature verification requires local proof"
        )
    process = subprocess.run(
        [
            openssl,
            "pkeyutl",
            "-verify",
            "-pubin",
            "-inkey",
            str(public_key),
            "-rawin",
            "-in",
            str(payload),
            "-sigfile",
            str(signature),
        ],
        check=False,
        capture_output=True,
        text=True,
    )
    if process.returncode != 0:
        raise Hold("Ed25519 signature verification failed")


def inspect_payload(payload: Path, expected_fingerprint: str) -> dict:
    with zipfile.ZipFile(payload) as archive:
        bad = archive.testzip()
        if bad:
            raise Hold(f"ZIP CRC failure: {bad}")
        if archive.comment:
            raise Hold("ZIP archive comment must be empty")

        infos = archive.infolist()
        exact: set[str] = set()
        folded: dict[str, str] = {}
        normalised: dict[str, str] = {}

        for info in infos:
            name = safe_name(info.filename)
            parts = PurePosixPath(name).parts
            if not parts or parts[0] != EXPECTED_ROOT:
                raise Hold(f"unexpected release root: {name}")
            if name in exact:
                raise Hold(f"duplicate ZIP member: {name}")
            exact.add(name)

            fold = name.casefold()
            if fold in folded and folded[fold] != name:
                raise Hold(f"case-fold collision: {folded[fold]} / {name}")
            folded[fold] = name

            nfc = unicodedata.normalize("NFC", name)
            if nfc in normalised and normalised[nfc] != name:
                raise Hold(f"Unicode collision: {normalised[nfc]} / {name}")
            normalised[nfc] = name

            mode = (info.external_attr >> 16) & 0xFFFF
            if stat.S_ISLNK(mode):
                raise Hold(f"symbolic link rejected: {name}")
            if info.flag_bits & 0x1:
                raise Hold(f"encrypted member rejected: {name}")
            if info.date_time != FIXED_TIME:
                raise Hold(f"non-normalised ZIP timestamp: {name}")
            if info.extra or info.comment:
                raise Hold(f"ZIP metadata residue: {name}")
            if name.endswith((".pyc", ".pyo")) or "/__pycache__/" in name:
                raise Hold(f"compiled bytecode rejected: {name}")

        prefix = EXPECTED_ROOT + "/"
        required = {
            "ARTIFACT_IDENTITY.json",
            "PUBLIC_PROVENANCE.json",
            "INWARD_SECURITY_CONTRACT.json",
            "SECURITY_DIMENSION_MATRIX.json",
            "RELEASE_ENVELOPE_POLICY.json",
            "COMPONENT_BINDING.json",
            "BUILD_RECIPE.json",
            "RELEASE_MANIFEST.json",
            "SHA256SUMS.txt",
            "RELEASE_PUBLIC_KEY.pem",
            "RELEASE_KEY_FINGERPRINT.txt",
            "LICENSE.txt",
            "NOTICE.md",
        }
        missing = sorted(
            item for item in required if prefix + item not in exact
        )
        if missing:
            raise Hold(f"required release files missing: {missing}")

        identity = json.loads(archive.read(prefix + "ARTIFACT_IDENTITY.json"))
        expected_identity = {
            "product": EXPECTED_PRODUCT,
            "publisher": EXPECTED_PUBLISHER,
            "version": EXPECTED_VERSION,
            "license": EXPECTED_LICENSE,
            "copyright": EXPECTED_COPYRIGHT,
            "canonical_route": EXPECTED_ROUTE,
        }
        for key, expected in expected_identity.items():
            if identity.get(key) != expected:
                raise Hold(f"identity mismatch for {key}")

        embedded_fingerprint_text = archive.read(
            prefix + "RELEASE_KEY_FINGERPRINT.txt"
        ).decode("utf-8", errors="strict")
        match = re.search(r"[0-9a-f]{64}", embedded_fingerprint_text)
        if not match or match.group(0) != expected_fingerprint:
            raise Hold("embedded key fingerprint mismatch")

        manifest = json.loads(archive.read(prefix + "RELEASE_MANIFEST.json"))
        if manifest.get("version") != EXPECTED_VERSION:
            raise Hold("release manifest version mismatch")
        for key, expected in expected_identity.items():
            manifest_value = (
                manifest.get("identity", {}).get(key)
                if key != "version"
                else manifest.get("version")
            )
            if manifest_value != expected:
                raise Hold(f"manifest identity mismatch for {key}")

        records = manifest.get("records")
        if not isinstance(records, list):
            raise Hold("manifest records missing")
        for record in records:
            relative = safe_name(record.get("path"))
            member = prefix + relative
            if member not in exact:
                raise Hold(f"manifest member missing: {relative}")
            data = archive.read(member)
            actual = hashlib.sha256(data).hexdigest()
            if actual != record.get("sha256") or len(data) != record.get("bytes"):
                raise Hold(f"manifest mismatch: {relative}")

        seen_sums: set[str] = set()
        for line in archive.read(prefix + "SHA256SUMS.txt").decode("utf-8").splitlines():
            if not line.strip():
                continue
            value, relative = line.split("  ", 1)
            if relative in seen_sums:
                raise Hold(f"duplicate checksum entry: {relative}")
            seen_sums.add(relative)
            member = prefix + safe_name(relative)
            if member not in exact:
                raise Hold(f"checksum member missing: {relative}")
            if hashlib.sha256(archive.read(member)).hexdigest() != value:
                raise Hold(f"checksum mismatch: {relative}")

        binding = json.loads(archive.read(prefix + "COMPONENT_BINDING.json"))
        binding_records = binding.get("records")
        if not isinstance(binding_records, list):
            raise Hold("component binding records missing")
        for record in binding_records:
            relative = safe_name(record.get("path"))
            member = prefix + relative
            if member not in exact:
                raise Hold(f"bound component missing: {relative}")
            data = archive.read(member)
            if (
                hashlib.sha256(data).hexdigest() != record.get("sha256")
                or len(data) != record.get("bytes")
            ):
                raise Hold(f"component binding mismatch: {relative}")

        matrix = json.loads(
            archive.read(prefix + "SECURITY_DIMENSION_MATRIX.json")
        )
        if matrix.get("dimensions") != 8 or matrix.get("stages") != 8:
            raise Hold("security dimension declaration mismatch")
        if len(matrix.get("matrix", [])) != 64:
            raise Hold("security dimension matrix must contain 64 cells")

        return {
            "members": len(infos),
            "manifest_records": len(records),
            "component_records": len(binding_records),
            "security_dimension_cells": len(matrix.get("matrix", [])),
            "identity": expected_identity,
        }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--payload", required=True, type=Path)
    parser.add_argument("--sha256", required=True, type=Path)
    parser.add_argument("--sha512", required=True, type=Path)
    parser.add_argument("--signature", required=True, type=Path)
    parser.add_argument("--public-key", required=True, type=Path)
    parser.add_argument("--fingerprint", required=True, type=Path)
    args = parser.parse_args()

    for path in (
        args.payload,
        args.sha256,
        args.sha512,
        args.signature,
        args.public_key,
        args.fingerprint,
    ):
        if not path.is_file() or path.is_symlink():
            raise Hold(f"required file missing or unsafe: {path}")

    expected_sha256 = read_sidecar(
        args.sha256, "sha256", args.payload.name
    )
    expected_sha512 = read_sidecar(
        args.sha512, "sha512", args.payload.name
    )
    actual_sha256 = digest(args.payload, "sha256")
    actual_sha512 = digest(args.payload, "sha512")
    if actual_sha256 != expected_sha256:
        raise Hold("payload SHA-256 mismatch")
    if actual_sha512 != expected_sha512:
        raise Hold("payload SHA-512 mismatch")

    fingerprint_text = args.fingerprint.read_text(encoding="utf-8")
    match = re.search(r"[0-9a-f]{64}", fingerprint_text)
    if not match:
        raise Hold("fingerprint file contains no SHA-256 value")
    expected_fingerprint = match.group(0)
    actual_fingerprint = key_fingerprint(args.public_key)
    if actual_fingerprint != expected_fingerprint:
        raise Hold("public-key fingerprint mismatch")

    verify_signature(args.payload, args.signature, args.public_key)
    payload_report = inspect_payload(args.payload, expected_fingerprint)

    print(json.dumps({
        "gate": "PASS",
        "payload": args.payload.name,
        "sha256": actual_sha256,
        "sha512": actual_sha512,
        "signature": "PASS",
        "public_key_der_sha256": actual_fingerprint,
        "publisher_identity": "REQUIRES_INDEPENDENT_PIN",
        "payload_report": payload_report,
        "proof_boundary": (
            "This verification proves consistency of recorded bytes and a "
            "supplied key. It does not prove malware-free status, universal "
            "safety, or publisher identity without independent key pinning."
        ),
    }, indent=2))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (
        Hold,
        OSError,
        ValueError,
        json.JSONDecodeError,
        zipfile.BadZipFile,
    ) as exc:
        print(f"HOLD: {exc}", file=sys.stderr)
        raise SystemExit(2)
