# GOLDLEVEL Defensive Archive Starter

**Publisher:** GOLDLEVEL (Gold Level)  
**Version:** 2.0.0-rc1  
**Licence:** MIT  
**Copyright:** Copyright (c) 2026 GOLDLEVEL  
**Canonical route:** https://goldlevel.co.uk/download/goldlevel-defensive-archive-starter/  
**State:** HARDENED_FULL_SPECTRUM_REVIEW_CANDIDATE

## Purpose

The starter creates and verifies bounded, content-addressed evidence
archives from:

- a selected local folder; or
- one explicitly named public HTTPS origin after network opt-in.

Captured material is treated as untrusted data. The tools do not execute
captured scripts, submit forms, use credentials, install packages, or grant
captured text authority over the receiving task.

## Full-spectrum review model

The release now carries security inward through:

- self-contained product, publisher, version, rights and route identity;
- predecessor and build provenance;
- component binding;
- deterministic packaging;
- SHA-256 and SHA-512;
- detached Ed25519 signatures;
- public-key fingerprint and key-continuity policy;
- wrapper-versus-payload separation;
- archive path and parser controls;
- active, disguised, encoded and opaque-content review signals;
- source-upload authority separation;
- sixty-four lifecycle security cells;
- future-drift watch states;
- explicit local-proof gaps;
- human release authority.

## Start

Local capture:

```bash
python3 capture-readonly.py \
  --folder ./public-export \
  --output ./public-export-capture.zip
```

Verify a capture:

```bash
python3 verify-archive.py ./public-export-capture.zip
```

Verify a full release envelope:

```bash
python3 verify-release-envelope.py \
  --payload goldlevel-defensive-archive-starter-v2.0.0-rc1.zip \
  --sha256 goldlevel-defensive-archive-starter-v2.0.0-rc1.zip.sha256 \
  --sha512 goldlevel-defensive-archive-starter-v2.0.0-rc1.zip.sha512 \
  --signature goldlevel-defensive-archive-starter-v2.0.0-rc1.zip.ed25519 \
  --public-key goldlevel-defensive-archive-starter-v2.0.0-rc1.release-public-key.pem \
  --fingerprint goldlevel-defensive-archive-starter-v2.0.0-rc1.release-key-fingerprint.txt
```

## Proof boundary

A successful archive verification supports readability and recorded byte
identity. It does not prove that captured material is safe, complete,
authentic, compliant, recoverable, uncompromised, or free from unknown
threats.

A valid signature proves consistency against a supplied public key. Final
publisher identity requires independent key pinning.

External antivirus, YARA and behavioural-sandbox evidence remain
`REQUIRES_LOCAL_PROOF`.

## Main records

- `ARTIFACT_IDENTITY.json`
- `PUBLIC_PROVENANCE.json`
- `INWARD_SECURITY_CONTRACT.json`
- `SECURITY_DIMENSION_MATRIX.json`
- `RELEASE_ENVELOPE_POLICY.json`
- `COMPONENT_BINDING.json`
- `BUILD_RECIPE.json`
- `EMERGENCE_WATCH_REGISTER.json`
- `SOURCE_UPLOAD_PROFILE.json`
- `ASSURANCE_GAP_REGISTER.json`
- `SECURITY_GROUNDING.json`

## Licence

MIT. See `LICENSE.txt`.
