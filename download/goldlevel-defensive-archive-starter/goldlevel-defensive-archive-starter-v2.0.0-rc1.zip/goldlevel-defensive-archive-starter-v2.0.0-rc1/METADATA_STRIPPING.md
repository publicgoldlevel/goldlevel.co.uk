# Metadata stripping policy

This release preserves only the metadata needed to identify, license, verify,
and use the public source artifact.

## Retained

- project name: GOLDLEVEL Defensive Archive Starter;
- publisher reference: GOLDLEVEL / Gold Level;
- release version;
- canonical public route;
- MIT licence and copyright notice;
- file hashes, release manifest, public key, and key fingerprint;
- explicit security and proof boundaries.

## Removed or normalised

- Python bytecode and `__pycache__`;
- source ZIP timestamps;
- ZIP extra fields and comments;
- build host, local username, device identifier, and local filesystem paths;
- exact build timestamp;
- editor, operating-system, and backup-file residue;
- private signing key;
- private transport keys;
- credentials, tokens, session values, and private contact information.

The deterministic ZIP timestamp is a packaging normalisation value, not the
release creation time.
---

**Product:** GOLDLEVEL Defensive Archive Starter  
**Publisher:** GOLDLEVEL (Gold Level)  
**Version:** 2.0.0-rc1  
**Licence:** MIT  
**Copyright:** Copyright (c) 2026 GOLDLEVEL  
**Canonical route:** https://goldlevel.co.uk/download/goldlevel-defensive-archive-starter/  
**Artifact role:** METADATA_STRIPPING  
**Audience:** PUBLIC  
**Release state:** HARDENED_FULL_SPECTRUM_REVIEW_CANDIDATE

