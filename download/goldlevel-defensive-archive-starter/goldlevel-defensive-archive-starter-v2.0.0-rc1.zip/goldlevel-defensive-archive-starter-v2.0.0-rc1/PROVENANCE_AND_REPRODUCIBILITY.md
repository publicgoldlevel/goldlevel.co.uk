# Provenance and reproducibility

    This candidate is a direct successor to:

    ```text
    goldlevel-defensive-archive-starter-v1.3.1.zip
    SHA-256 fde36977f5af75802ce4fa8bef6c087429f4dc6e461d6d28476a9cc4d4ebf9e8
    SHA-512 9ccc6398f1b8ddf9176303b33824f5fa5824bb7bbac9e754ca0b18004f3eacad9850fd6dd76124a2d5e1024b18539da1403603ebf822a8a5e55bc2a6c68197ee
    ```

    The build is deterministic at the ZIP-byte level when the same source tree,
    embedded public key, and build recipe are used.

    Reproducibility does not prove that a build is benign. A malicious or
    compromised build process can also be reproducible. Independent review,
    source binding, key continuity, external scanning and delivery verification
    remain separate controls.

    The final canonical public release must be rebuilt and signed with an
    operator-controlled, independently pinned signing identity. This cloud-built
    candidate uses a provisional review key and is not represented as the
    enduring public trust root.

---

**Product:** GOLDLEVEL Defensive Archive Starter  
**Publisher:** GOLDLEVEL (Gold Level)  
**Version:** 2.0.0-rc1  
**Licence:** MIT  
**Copyright:** Copyright (c) 2026 GOLDLEVEL  
**Canonical route:** https://goldlevel.co.uk/download/goldlevel-defensive-archive-starter/  
**Artifact role:** PROVENANCE_AND_REPRODUCIBILITY_GUIDE  
**Audience:** PUBLIC  
**Release state:** HARDENED_FULL_SPECTRUM_REVIEW_CANDIDATE
