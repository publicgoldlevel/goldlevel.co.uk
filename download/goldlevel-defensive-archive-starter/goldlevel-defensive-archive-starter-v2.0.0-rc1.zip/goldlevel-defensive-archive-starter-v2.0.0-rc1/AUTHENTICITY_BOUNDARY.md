# Authenticity boundary

    SHA-256 and SHA-512 identify exact bytes.

    A detached Ed25519 signature proves that the named payload matches the
    supplied public key. It does not, by itself, prove who controls that key.

    Candidate public-key DER SHA-256:

    ```text
    9c2d0c40fe8b2c6c70f19cda0e00a78c0c1c47b500f4c21431b7c3947069f8b9
    ```

    Publisher identity requires independent pinning of the final public key or
    fingerprint. Replacing a ZIP, signature, key, and fingerprint together
    defeats a self-contained identity check.

    This release also distinguishes:

    - inner payload identity;
    - outer source-upload packet identity;
    - predecessor identity;
    - component identity;
    - route identity;
    - signing-key identity.

    Those identities must never be merged into one undifferentiated “verified”
    state.

---

**Product:** GOLDLEVEL Defensive Archive Starter  
**Publisher:** GOLDLEVEL (Gold Level)  
**Version:** 2.0.0-rc1  
**Licence:** MIT  
**Copyright:** Copyright (c) 2026 GOLDLEVEL  
**Canonical route:** https://goldlevel.co.uk/download/goldlevel-defensive-archive-starter/  
**Artifact role:** AUTHENTICITY_BOUNDARY  
**Audience:** PUBLIC  
**Release state:** HARDENED_FULL_SPECTRUM_REVIEW_CANDIDATE
