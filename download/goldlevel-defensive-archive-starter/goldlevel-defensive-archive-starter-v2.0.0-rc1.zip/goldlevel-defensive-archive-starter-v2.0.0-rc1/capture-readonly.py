#!/usr/bin/env python3
# Product: GOLDLEVEL Defensive Archive Starter
# Publisher: GOLDLEVEL
# Version: 2.0.0-rc1
# Licence: MIT
# Copyright: Copyright (c) 2026 GOLDLEVEL
# Canonical route: https://goldlevel.co.uk/download/goldlevel-defensive-archive-starter/
# Release state: HARDENED_FULL_SPECTRUM_REVIEW_CANDIDATE
"""Create a bounded, content-addressed defensive capture ZIP."""
from __future__ import annotations

import argparse
import hashlib
import html.parser
import http.client
import ipaddress
import io
import json
import os
import re
import socket
import ssl
import stat
import sys
import tempfile
import unicodedata
import urllib.parse
import zipfile
from collections import deque
from pathlib import Path, PurePosixPath

VERSION = "2.0.0-rc1"
FIXED_TIME = (1980, 1, 1, 0, 0, 0)
DEFAULT_MAX_ITEMS = 2000
DEFAULT_MAX_OBJECT_BYTES = 10 * 1024 * 1024
DEFAULT_MAX_TOTAL_BYTES = 50 * 1024 * 1024
DEFAULT_MAX_PARSE_BYTES = 2 * 1024 * 1024
DEFAULT_TIMEOUT = 12.0
MAX_REDIRECTS = 5
MAX_URL_CHARS = 8192
MAX_LINKS_PER_OBJECT = 5000
MAX_CLASSIFY_BYTES = 10 * 1024 * 1024
MAX_SEMANTIC_BYTES = 2 * 1024 * 1024
CLASSIFY_WINDOW_COUNT = 5
KNOWN_IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".tif", ".tiff", ".ico", ".avif"}
KNOWN_MEDIA_SUFFIXES = {".mp3", ".wav", ".ogg", ".flac", ".mp4", ".webm", ".mov", ".m4a"}
USER_AGENT = "GOLDLEVEL-Defensive-Archive-Starter/2.0.0-rc1"

ALLOWED_HEADERS = {
    "content-type", "content-length", "content-language", "content-encoding",
    "cache-control", "etag", "last-modified", "expires", "vary",
    "content-security-policy", "strict-transport-security",
    "x-content-type-options", "referrer-policy", "permissions-policy",
    "cross-origin-opener-policy", "cross-origin-resource-policy",
    "cross-origin-embedder-policy", "location",
}
RISKY_DIRS = {".git", ".hg", ".svn", "node_modules", "__pycache__"}
RISKY_EXACT = {
    ".env", "id_rsa", "id_dsa", "id_ecdsa", "id_ed25519",
    "authorized_keys", "known_hosts",
}
RISKY_SUFFIXES = {".pem", ".key", ".p12", ".pfx", ".jks", ".keystore"}
RISKY_WORDS = re.compile(r"(?:credential|secret|token|private[_-]?key)", re.I)
CSS_URL_RE = re.compile(r"url\(\s*(['\"]?)(.*?)\1\s*\)", re.I)
CSS_IMPORT_RE = re.compile(r"@import\s+(?:url\()?\s*(['\"])(.*?)\1", re.I)
TAG_RE = re.compile(r"<[^>]{0,512}>")
SPACE_RE = re.compile(r"\s+")

PROMPT_PATTERNS = (
    ("ignore_prior", re.compile(r"\b(?:ignore|disregard|discard|forget|bypass|supersede|override)\b.{0,80}\b(?:previous|prior|earlier|above|original)\b.{0,80}\b(?:instruction|instructions|direction|directions|guidance|rules|policy|prompt|constraints|guardrails)\b")),
    ("disclose_hidden", re.compile(r"\b(?:reveal|disclose|expose|show|print|repeat|provide)\b.{0,80}\b(?:hidden|internal|system|developer|secret|private)\b.{0,80}\b(?:rules|instructions|prompt|message|policy|configuration|guidance)\b")),
    ("system_prompt", re.compile(r"\b(?:system|developer)\b.{0,40}\b(?:prompt|message|instructions|rules)\b")),
    ("tool_override", re.compile(r"\b(?:tool\s+call|call\s+(?:a\s+)?tool|run\s+(?:a\s+)?tool|execute\s+(?:a\s+)?tool)\b")),
    ("safety_override", re.compile(r"\b(?:override|bypass|disable|evade)\b.{0,60}\b(?:policy|guardrails|safety|instructions|restrictions|controls)\b")),
    ("secret_exfiltration", re.compile(r"\b(?:exfiltrate|transmit|send|leak|export)\b.{0,60}\b(?:secret|credential|token|key|password|private\s+data)\b")),
    ("role_replacement", re.compile(r"\b(?:act\s+as|you\s+are\s+now|replace\s+your\s+role|new\s+role)\b.{0,80}\b(?:system|developer|administrator|unrestricted|uncensored)\b")),
    ("do_not_follow", re.compile(r"\bdo\s+not\s+follow\b.{0,60}\b(?:prior|previous|earlier|instructions|rules|guidance)\b")),
)

OVERRIDE_VERBS = {
    "ignore", "disregard", "discard", "forget", "bypass", "supersede",
    "override", "evade", "disable", "replace",
}
PRIOR_TERMS = {"previous", "prior", "earlier", "above", "original", "initial"}
INSTRUCTION_TERMS = {
    "instruction", "instructions", "direction", "directions", "guidance",
    "rule", "rules", "policy", "policies", "prompt", "prompts",
    "constraint", "constraints", "guardrail", "guardrails",
}
DISCLOSURE_VERBS = {
    "reveal", "disclose", "expose", "show", "print", "repeat", "provide",
    "dump", "display",
}
PROTECTED_TERMS = {
    "hidden", "internal", "system", "developer", "secret", "private",
    "configuration", "message", "prompt", "instructions", "rules",
}
ACTION_TERMS = {"tool", "execute", "run", "call", "send", "transmit", "exfiltrate", "leak"}
SENSITIVE_TERMS = {"secret", "credential", "credentials", "token", "key", "password", "private"}
ROLE_TERMS = {"system", "developer", "administrator", "unrestricted", "uncensored"}
BIDI_CONTROLS = {
    "\u061c", "\u200e", "\u200f", "\u202a", "\u202b", "\u202c",
    "\u202d", "\u202e", "\u2066", "\u2067", "\u2068", "\u2069",
}
EICAR = b"X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*"


class Hold(RuntimeError):
    pass


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical_json(obj: object) -> bytes:
    return (json.dumps(obj, indent=2, sort_keys=True, ensure_ascii=False) + "\n").encode("utf-8")


def zip_info(name: str) -> zipfile.ZipInfo:
    info = zipfile.ZipInfo(name, FIXED_TIME)
    info.compress_type = zipfile.ZIP_DEFLATED
    info.create_system = 3
    info.external_attr = (stat.S_IFREG | 0o644) << 16
    info.flag_bits |= 0x800
    return info


def safe_relative(raw: str) -> str:
    if not raw or "\\" in raw or "\x00" in raw:
        raise Hold(f"unsafe relative path: {raw!r}")
    path = PurePosixPath(raw)
    if path.is_absolute() or any(part in {"", ".", ".."} for part in path.parts):
        raise Hold(f"unsafe relative path: {raw!r}")
    normal = unicodedata.normalize("NFC", path.as_posix())
    if normal != path.as_posix():
        raise Hold(f"non-canonical Unicode path: {raw!r}")
    return normal


def receipt_text(value: object, limit: int = 8192) -> str:
    text = unicodedata.normalize("NFC", str(value))
    output: list[str] = []
    for char in text:
        category = unicodedata.category(char)
        if char in BIDI_CONTROLS or category == "Cf":
            continue
        if category.startswith("C") and char not in "\t\n\r":
            output.append("\uFFFD")
        else:
            output.append(char)
    return "".join(output)[:limit]




def bounded_windows(data: bytes, limit: int, windows: int = CLASSIFY_WINDOW_COUNT) -> bytes:
    if limit <= 0:
        return b""
    if len(data) <= limit:
        return data
    windows = max(3, windows)
    width = max(1, limit // windows)
    max_start = max(0, len(data) - width)
    starts = {
        0,
        max_start,
        max(0, len(data) // 4 - width // 2),
        max(0, len(data) // 2 - width // 2),
        max(0, (3 * len(data)) // 4 - width // 2),
    }
    chunks = [data[start:start + width] for start in sorted(starts)]
    return b"\n".join(chunks)[:limit]


def semantic_text(data: bytes) -> str:
    sample = bounded_windows(data, MAX_SEMANTIC_BYTES).decode("utf-8", errors="replace")
    sample = unicodedata.normalize("NFKC", sample)
    sample = "".join(char for char in sample if unicodedata.category(char) != "Cf")
    sample = TAG_RE.sub(" ", sample)
    sample = "".join(char if char.isalnum() else " " for char in sample.casefold())
    return SPACE_RE.sub(" ", sample).strip()


def instruction_analysis(data: bytes) -> dict:
    text = semantic_text(data)
    tokens = set(text.split())
    signals: list[str] = []
    score = 0

    for label, pattern in PROMPT_PATTERNS:
        if pattern.search(text):
            signals.append(f"pattern:{label}")
            score += 4

    has_override = bool(tokens & OVERRIDE_VERBS)
    has_prior = bool(tokens & PRIOR_TERMS)
    has_instruction = bool(tokens & INSTRUCTION_TERMS)
    has_disclosure = bool(tokens & DISCLOSURE_VERBS)
    has_protected = bool(tokens & PROTECTED_TERMS)
    has_action = bool(tokens & ACTION_TERMS)
    has_sensitive = bool(tokens & SENSITIVE_TERMS)
    has_role = bool(tokens & ROLE_TERMS)

    if has_override and has_instruction:
        signals.append("semantic:override_instruction")
        score += 3
    if has_override and has_prior:
        signals.append("semantic:override_prior")
        score += 2
    if has_disclosure and has_protected:
        signals.append("semantic:disclose_protected")
        score += 3
    if has_disclosure and has_instruction and ("hidden" in tokens or "internal" in tokens):
        signals.append("semantic:disclose_hidden_rules")
        score += 3
    if has_action and has_sensitive:
        signals.append("semantic:action_sensitive")
        score += 3
    if has_role and ("prompt" in tokens or "instructions" in tokens or "rules" in tokens):
        signals.append("semantic:role_instruction")
        score += 2

    return {
        "detected": score >= 3,
        "score": score,
        "threshold": 3,
        "signals": sorted(set(signals)),
        "normalisation": "NFKC+format-control-removal+markup-separation+casefold",
    }


def instruction_like(data: bytes) -> bool:
    return bool(instruction_analysis(data)["detected"])


def active_web_analysis(data: bytes) -> dict:
    sample = bounded_windows(data, MAX_CLASSIFY_BYTES)
    signals: list[str] = []
    bases: list[str] = []

    byte_views = {
        "raw": sample.lower(),
        "nul_stripped": sample.replace(b"\x00", b"").lower(),
    }
    byte_patterns = (
        (b"<script", "html_script_tag"),
        (b"</script", "html_script_close"),
        (b"<!doctype html", "html_doctype"),
        (b"<html", "html_root"),
        (b"<iframe", "html_iframe"),
        (b"<object", "html_object"),
        (b"<embed", "html_embed"),
        (b"<svg", "svg_markup"),
        (b"<foreignobject", "svg_foreign_object"),
        (b"javascript:", "javascript_uri"),
        (b"data:text/html", "active_data_uri"),
        (b"srcdoc=", "iframe_srcdoc"),
        (b"onload=", "inline_event_handler"),
        (b"onerror=", "inline_event_handler"),
        (b"onclick=", "inline_event_handler"),
        (b"document.cookie", "browser_script_api"),
        (b"window.location", "browser_script_api"),
        (b"serviceworker", "service_worker_marker"),
        (b"navigator.serviceworker", "service_worker_marker"),
        (b"http-equiv", "meta_http_equiv"),
    )

    for view_name, view in byte_views.items():
        for needle, label in byte_patterns:
            if needle in view:
                signals.append(label)
                bases.append(f"bytes:{view_name}")

    text_views: list[tuple[str, str]] = []
    for encoding in ("utf-8", "utf-16-le", "utf-16-be"):
        try:
            decoded = sample.decode(encoding, errors="ignore")
        except LookupError:
            continue
        decoded = unicodedata.normalize("NFKC", decoded)
        decoded = html.unescape(decoded).casefold()
        decoded = "".join(char for char in decoded if unicodedata.category(char) != "Cf")
        text_views.append((encoding, decoded))

    text_patterns = (
        ("<script", "html_script_tag"),
        ("javascript:", "javascript_uri"),
        ("data:text/html", "active_data_uri"),
        ("srcdoc=", "iframe_srcdoc"),
        ("onload=", "inline_event_handler"),
        ("onerror=", "inline_event_handler"),
        ("<foreignobject", "svg_foreign_object"),
        ("navigator.serviceworker", "service_worker_marker"),
    )
    for encoding, view in text_views:
        for needle, label in text_patterns:
            if needle in view:
                signals.append(label)
                bases.append(f"text:{encoding}")

    stripped = byte_views["nul_stripped"].lstrip(b"\xef\xbb\xbf\t\r\n ")
    if stripped.startswith((b"<html", b"<!doctype html", b"<script", b"<?xml")):
        signals.append("markup_leading_signature")
        bases.append("bytes:leading")

    return {
        "detected": bool(signals),
        "signals": sorted(set(signals)),
        "sample_bytes": len(sample),
        "basis": sorted(set(bases)) or ["byte-content-sniffing"],
        "encodings_considered": ["utf-8", "utf-16-le", "utf-16-be"],
    }


def inspect_zip_container(data: bytes) -> list[str]:
    flags: list[str] = []
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as nested:
            infos = nested.infolist()
            if len(infos) > 5000:
                return ["archive_container", "nested_member_limit"]

            total = 0
            exact: set[str] = set()
            folded: dict[str, str] = {}
            normalised: dict[str, str] = {}
            names: set[str] = set()

            for item in infos:
                total += item.file_size
                raw = item.filename
                path = PurePosixPath(raw)

                if (
                    not raw
                    or "\\" in raw
                    or "\x00" in raw
                    or path.is_absolute()
                    or any(part in {"", ".", ".."} for part in path.parts)
                ):
                    flags.append("nested_unsafe_path")

                if raw in exact:
                    flags.append("nested_duplicate_member")
                exact.add(raw)

                fold = raw.casefold()
                if fold in folded and folded[fold] != raw:
                    flags.append("nested_case_collision")
                folded[fold] = raw

                nfc = unicodedata.normalize("NFC", raw)
                if nfc in normalised and normalised[nfc] != raw:
                    flags.append("nested_unicode_collision")
                normalised[nfc] = raw

                mode = (item.external_attr >> 16) & 0xFFFF
                if stat.S_ISLNK(mode):
                    flags.append("nested_symlink")
                if item.flag_bits & 0x1:
                    flags.append("nested_encrypted_member")

                if item.compress_size == 0 and item.file_size > 0:
                    flags.append("nested_decompression_ratio")
                elif item.compress_size > 0 and item.file_size / item.compress_size > 1000:
                    flags.append("nested_decompression_ratio")

                names.add(raw.casefold())

            if total > 100 * 1024 * 1024:
                flags.append("nested_size_limit")
            if any(name.endswith("vbaproject.bin") for name in names):
                flags.append("macro_enabled_document")
            if any("/embeddings/" in name for name in names):
                flags.append("embedded_object")
            if any(name.startswith("xl/externallinks/") for name in names):
                flags.append("external_document_link")
    except (zipfile.BadZipFile, RuntimeError, OSError):
        flags.append("malformed_archive_container")
    return sorted(set(flags))



def classify_content(data: bytes, source: str, content_type: str = "") -> dict:
    low = source.casefold()
    mime = content_type.split(";", 1)[0].strip().casefold()
    flags: list[str] = []
    content_class = "binary"
    detection_basis: list[str] = []

    metadata_web = (
        mime in {"text/html", "application/xhtml+xml", "application/javascript", "text/javascript"}
        or low.endswith((".html", ".htm", ".xhtml", ".js", ".mjs", ".svg"))
    )
    web_analysis = active_web_analysis(data)
    prompt_analysis = instruction_analysis(data)
    suffixes = [part.casefold() for part in PurePosixPath(source).name.split(".") if part]
    if len(suffixes) >= 3 and suffixes[-2] in {
        "exe", "dll", "js", "mjs", "html", "htm", "svg", "zip", "pdf"
    }:
        flags.append("suspicious_double_extension")
        detection_basis.append("metadata:double_extension")

    if EICAR in data:
        flags.append("standard_test_signature")
        detection_basis.append("byte_signature:eicar")
    if data.startswith(b"MZ") or data.startswith(b"\x7fELF") or data[:4] in {
        b"\xfe\xed\xfa\xce", b"\xfe\xed\xfa\xcf", b"\xce\xfa\xed\xfe", b"\xcf\xfa\xed\xfe",
    }:
        content_class = "executable"
        flags.append("executable_signature")
        detection_basis.append("byte_signature:executable")
    elif data.startswith((b"PK\x03\x04", b"7z\xbc\xaf\x27\x1c", b"Rar!\x1a\x07", b"\x1f\x8b")):
        content_class = "archive"
        flags.append("archive_container")
        flags.extend(inspect_zip_container(data))
        detection_basis.append("byte_signature:archive")
    elif data.startswith(b"%PDF"):
        content_class = "document"
        detection_basis.append("byte_signature:pdf")
        sample = bounded_windows(data, MAX_CLASSIFY_BYTES)
        if (
            b"/JavaScript" in sample
            or b"/JS" in sample
            or b"/OpenAction" in sample
            or b"/Launch" in sample
            or b"/EmbeddedFile" in sample
        ):
            flags.append("active_document")
    elif data.startswith(b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"):
        content_class = "document"
        flags.append("active_document")
        detection_basis.append("byte_signature:ole")
    elif web_analysis["detected"]:
        signals = set(web_analysis["signals"])
        if any("script" in signal or "javascript" in signal or "browser_script" in signal for signal in signals):
            content_class = "script_or_markup"
        else:
            content_class = "markup"
        flags.append("active_web_content")
        detection_basis.append("byte_content:web")
        if not metadata_web:
            flags.append("disguised_active_content")
        if mime.startswith(("image/", "audio/", "video/")):
            flags.append("metadata_content_mismatch")
    elif metadata_web:
        content_class = "script_or_markup"
        flags.append("active_web_content")
        detection_basis.append("metadata:web")
    elif mime.startswith("text/") or low.endswith((".txt", ".md", ".css", ".json", ".xml", ".csv", ".py", ".sh")):
        content_class = "text"
        detection_basis.append("metadata:text")
    elif mime.startswith("image/") or any(low.endswith(suffix) for suffix in KNOWN_IMAGE_SUFFIXES):
        content_class = "image"
        detection_basis.append("metadata_or_suffix:image")
    elif mime.startswith(("audio/", "video/")) or any(low.endswith(suffix) for suffix in KNOWN_MEDIA_SUFFIXES):
        content_class = "media"
        detection_basis.append("metadata_or_suffix:media")
    elif content_class == "binary":
        flags.append("opaque_binary_content")
        detection_basis.append("unknown:opaque_binary")

    if prompt_analysis["detected"]:
        flags.append("instruction_like_text")
        detection_basis.append("semantic:instruction")

    signature_families = 0
    if data.startswith((b"MZ", b"\x7fELF", b"%PDF", b"PK\x03\x04")):
        signature_families += 1
    if web_analysis["detected"]:
        signature_families += 1
    if data.startswith(b"%PDF") and b"PK\x03\x04" in data[-131072:]:
        signature_families += 1
    if signature_families > 1:
        flags.append("polyglot_signal")
        detection_basis.append("byte_content:multiple_families")

    flags = sorted(set(flags))
    return {
        "content_class": content_class,
        "risk_flags": flags,
        "review_required": bool(flags),
        "detection_basis": sorted(set(detection_basis)),
        "active_web_analysis": web_analysis,
        "instruction_analysis": prompt_analysis,
    }


def risky_local_path(relative: str) -> str | None:
    parts = PurePosixPath(relative).parts
    if any(part in RISKY_DIRS for part in parts):
        return "excluded_directory"
    name = parts[-1]
    low = name.casefold()
    if low in RISKY_EXACT or low.startswith(".env."):
        return "credential_like_filename"
    if any(low.endswith(suffix) for suffix in RISKY_SUFFIXES):
        return "key_or_certificate_container"
    if RISKY_WORDS.search(name):
        return "secret_like_filename"
    return None


def read_regular_file(path: Path, max_bytes: int) -> bytes:
    flags = os.O_RDONLY
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    descriptor = os.open(path, flags)
    try:
        before = os.fstat(descriptor)
        if not stat.S_ISREG(before.st_mode):
            raise Hold(f"not a regular file: {path}")
        if before.st_size > max_bytes:
            raise Hold(f"file exceeds object limit: {path}")
        chunks: list[bytes] = []
        total = 0
        while True:
            chunk = os.read(descriptor, min(1024 * 1024, max_bytes + 1 - total))
            if not chunk:
                break
            total += len(chunk)
            if total > max_bytes:
                raise Hold(f"file exceeds object limit while reading: {path}")
            chunks.append(chunk)
        after = os.fstat(descriptor)
        before_id = (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns)
        after_id = (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
        if before_id != after_id:
            raise Hold(f"file changed during capture: {path}")
        return b"".join(chunks)
    finally:
        os.close(descriptor)


def local_capture(root: Path, max_items: int, max_object_bytes: int, max_total_bytes: int):
    root = root.resolve(strict=True)
    if not root.is_dir():
        raise Hold("--folder must name an existing directory")

    records: list[dict] = []
    objects: dict[str, bytes] = {}
    omissions: list[dict] = []
    notes: list[str] = []
    seen_case: dict[str, str] = {}
    seen_nfc: dict[str, str] = {}
    total = 0

    for base, dirs, files in os.walk(root, topdown=True, followlinks=False):
        base_path = Path(base)
        kept_dirs: list[str] = []
        for name in sorted(dirs):
            candidate = base_path / name
            raw = candidate.relative_to(root).as_posix()
            try:
                relative = safe_relative(raw)
            except Hold as exc:
                omissions.append({"item": receipt_text(raw), "state": "QUALIFIED", "reason": receipt_text(exc)})
                continue
            if candidate.is_symlink():
                omissions.append({"item": relative, "state": "QUALIFIED", "reason": "symlink_not_followed"})
                continue
            reason = risky_local_path(relative)
            if reason:
                omissions.append({"item": relative, "state": "QUALIFIED", "reason": reason})
                continue
            kept_dirs.append(name)
        dirs[:] = kept_dirs

        for name in sorted(files):
            path = base_path / name
            relative = safe_relative(path.relative_to(root).as_posix())
            if len(records) >= max_items:
                notes.append("item_limit_reached")
                return records, objects, omissions, notes
            if path.is_symlink():
                omissions.append({"item": relative, "state": "QUALIFIED", "reason": "symlink_not_followed"})
                continue
            reason = risky_local_path(relative)
            if reason:
                omissions.append({"item": relative, "state": "QUALIFIED", "reason": reason})
                continue
            folded = relative.casefold()
            normal = unicodedata.normalize("NFC", relative)
            if folded in seen_case and seen_case[folded] != relative:
                raise Hold(f"case-fold collision: {seen_case[folded]!r} and {relative!r}")
            if normal in seen_nfc and seen_nfc[normal] != relative:
                raise Hold(f"Unicode-normalisation collision: {seen_nfc[normal]!r} and {relative!r}")
            seen_case[folded] = relative
            seen_nfc[normal] = relative

            try:
                data = read_regular_file(path, max_object_bytes)
            except (Hold, OSError) as exc:
                omissions.append({"item": relative, "state": "QUALIFIED", "reason": type(exc).__name__})
                continue
            if total + len(data) > max_total_bytes:
                omissions.append({"item": relative, "state": "QUALIFIED", "reason": "total_byte_limit"})
                notes.append("total_byte_limit_reached")
                return records, objects, omissions, notes

            digest = sha256_bytes(data)
            objects.setdefault(digest, data)
            total += len(data)
            records.append({
                "kind": "local_file",
                "source": relative,
                "state": "CAPTURED",
                "bytes": len(data),
                "sha256": digest,
                "object": f"objects/{digest}",
                **classify_content(data, relative),
            })

    return records, objects, omissions, notes


def effective_port(parts: urllib.parse.SplitResult) -> int:
    return parts.port or 443


def canonical_origin(url: str):
    if len(url) > MAX_URL_CHARS or any(ord(char) < 32 for char in url) or "\\" in url:
        raise Hold("origin violates URL policy")
    parts = urllib.parse.urlsplit(url)
    if parts.scheme.casefold() != "https":
        raise Hold("network capture requires an https:// origin")
    if not parts.hostname or parts.username or parts.password:
        raise Hold("origin must contain a hostname and no embedded credentials")
    if parts.query or parts.fragment:
        raise Hold("origin must not contain a query or fragment")
    try:
        host = parts.hostname.encode("idna").decode("ascii").casefold().rstrip(".")
    except UnicodeError as exc:
        raise Hold("origin hostname cannot be canonicalised") from exc
    port = effective_port(parts)
    netloc = host if port == 443 else f"{host}:{port}"
    normalized = urllib.parse.urlunsplit(("https", netloc, parts.path or "/", "", ""))
    return normalized, urllib.parse.urlsplit(normalized)


def resolve_public_addresses(host: str, port: int) -> list[str]:
    try:
        infos = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
    except OSError as exc:
        raise Hold(f"DNS resolution failed: {type(exc).__name__}") from exc
    addresses = sorted({item[4][0] for item in infos})
    if not addresses:
        raise Hold("DNS returned no addresses")
    for raw in addresses:
        if not ipaddress.ip_address(raw).is_global:
            raise Hold(f"origin resolves to a non-public address: {raw}")
    return addresses


def same_origin(url: str, origin: urllib.parse.SplitResult) -> bool:
    parts = urllib.parse.urlsplit(url)
    if not parts.hostname:
        return False
    try:
        host = parts.hostname.encode("idna").decode("ascii").casefold().rstrip(".")
    except UnicodeError:
        return False
    return (
        parts.scheme.casefold() == "https"
        and host == (origin.hostname or "").casefold().rstrip(".")
        and effective_port(parts) == effective_port(origin)
        and not parts.username
        and not parts.password
    )


def normalize_url(raw: str, base: str, origin: urllib.parse.SplitResult) -> str | None:
    raw = receipt_text(raw, MAX_URL_CHARS).strip()
    if not raw or "\\" in raw or any(ord(char) < 32 for char in raw):
        return None
    if raw.casefold().startswith(("#", "data:", "javascript:", "mailto:", "tel:", "file:")):
        return None
    joined = urllib.parse.urljoin(base, raw)
    if len(joined) > MAX_URL_CHARS:
        return None
    parts = urllib.parse.urlsplit(joined)._replace(fragment="")
    normalized = urllib.parse.urlunsplit(parts)
    return normalized if same_origin(normalized, origin) else None


class LinkCollector(html.parser.HTMLParser):
    ATTRS = {
        "a": {"href"}, "img": {"src", "srcset"}, "source": {"src", "srcset"},
        "link": {"href"}, "script": {"src"}, "iframe": {"src"},
        "video": {"src", "poster"}, "audio": {"src"},
    }

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.links: list[str] = []

    def handle_starttag(self, tag: str, attrs):
        wanted = self.ATTRS.get(tag.casefold())
        if not wanted or len(self.links) >= MAX_LINKS_PER_OBJECT:
            return
        for key, value in attrs:
            if not value or key.casefold() not in wanted:
                continue
            value = receipt_text(value, MAX_URL_CHARS)
            if key.casefold() == "srcset":
                for part in value.split(","):
                    candidate = part.strip().split()[0] if part.strip() else ""
                    if candidate:
                        self.links.append(candidate)
            else:
                self.links.append(value)
            if len(self.links) >= MAX_LINKS_PER_OBJECT:
                break


class PinnedHTTPSConnection(http.client.HTTPSConnection):
    def __init__(self, host: str, port: int, address: str, timeout: float):
        super().__init__(host, port=port, timeout=timeout, context=ssl.create_default_context())
        self._address = address

    def connect(self) -> None:
        raw = socket.create_connection((self._address, self.port), self.timeout)
        self.sock = self._context.wrap_socket(raw, server_hostname=self.host)


def request_once(url: str, origin: urllib.parse.SplitResult, timeout: float, max_bytes: int):
    parts = urllib.parse.urlsplit(url)
    if not same_origin(url, origin):
        raise Hold("request escaped origin")
    host = parts.hostname or ""
    port = effective_port(parts)
    addresses = resolve_public_addresses(host, port)
    target = urllib.parse.urlunsplit(("", "", parts.path or "/", parts.query, ""))
    last_error: Exception | None = None

    for address in addresses:
        connection = PinnedHTTPSConnection(host, port, address, timeout)
        try:
            connection.request(
                "GET",
                target,
                headers={
                    "User-Agent": USER_AGENT,
                    "Accept": "text/html,application/xhtml+xml,text/css,application/json,image/*,*/*;q=0.1",
                    "Accept-Encoding": "identity",
                    "Cache-Control": "no-cache",
                    "Connection": "close",
                },
            )
            response = connection.getresponse()
            headers = {
                receipt_text(key.casefold(), 128): receipt_text(value, 2048)
                for key, value in response.getheaders()
                if key.casefold() in ALLOWED_HEADERS
            }
            length = headers.get("content-length")
            if length and length.isdigit() and int(length) > max_bytes:
                raise Hold("response Content-Length exceeds object limit")
            data = bytearray()
            while True:
                chunk = response.read(min(1024 * 1024, max_bytes + 1 - len(data)))
                if not chunk:
                    break
                data.extend(chunk)
                if len(data) > max_bytes:
                    raise Hold("response exceeded object byte limit")
            return response.status, headers, bytes(data), address
        except (OSError, ssl.SSLError, http.client.HTTPException, Hold) as exc:
            last_error = exc
        finally:
            connection.close()

    raise Hold(f"all accepted public addresses failed: {type(last_error).__name__ if last_error else 'unknown'}")


def fetch_with_redirects(url: str, origin: urllib.parse.SplitResult, timeout: float, max_bytes: int):
    current = url
    chain: list[str] = []
    for _ in range(MAX_REDIRECTS + 1):
        status, headers, data, address = request_once(current, origin, timeout, max_bytes)
        if status in {301, 302, 303, 307, 308}:
            location = headers.get("location")
            if not location:
                raise Hold("redirect response lacks Location")
            target = normalize_url(location, current, origin)
            if target is None:
                raise Hold("cross-origin or invalid redirect rejected")
            chain.append(current)
            current = target
            continue
        return status, headers, data, current, chain, address
    raise Hold("redirect limit exceeded")


def network_capture(origin_url: str, max_items: int, max_object_bytes: int,
                    max_total_bytes: int, max_parse_bytes: int, timeout: float):
    start, origin = canonical_origin(origin_url)
    initial_addresses = resolve_public_addresses(origin.hostname or "", effective_port(origin))
    queue = deque([start])
    queued = {start}
    records: list[dict] = []
    objects: dict[str, bytes] = {}
    omissions: list[dict] = []
    notes: list[str] = []
    total = 0

    while queue and len(records) < max_items:
        url = queue.popleft()
        remaining = max_total_bytes - total
        if remaining <= 0:
            notes.append("total_byte_limit_reached")
            break
        try:
            status, headers, data, final_url, redirects, address = fetch_with_redirects(
                url, origin, timeout, min(max_object_bytes, remaining)
            )
            total += len(data)
            digest = sha256_bytes(data)
            content_type = headers.get("content-type", "")
            objects.setdefault(digest, data)
            records.append({
                "kind": "https_resource",
                "source": receipt_text(url, MAX_URL_CHARS),
                "final_url": receipt_text(final_url, MAX_URL_CHARS),
                "state": "CAPTURED",
                "status": status,
                "headers": headers,
                "connected_public_address": address,
                "redirect_chain": [receipt_text(item, MAX_URL_CHARS) for item in redirects],
                "bytes": len(data),
                "sha256": digest,
                "object": f"objects/{digest}",
                **classify_content(data, final_url, content_type),
            })

            links: list[str] = []
            if len(data) <= max_parse_bytes:
                mime = content_type.split(";", 1)[0].strip().casefold()
                if mime in {"text/html", "application/xhtml+xml"}:
                    parser = LinkCollector()
                    parser.feed(data.decode("utf-8", errors="replace"))
                    links.extend(parser.links)
                elif mime == "text/css":
                    text = data.decode("utf-8", errors="replace")
                    links.extend(match.group(2) for match in CSS_URL_RE.finditer(text))
                    links.extend(match.group(2) for match in CSS_IMPORT_RE.finditer(text))
            else:
                notes.append("parse_byte_limit_reached")

            for raw in links[:MAX_LINKS_PER_OBJECT]:
                candidate = normalize_url(raw, final_url, origin)
                if candidate is None:
                    if raw.strip().casefold().startswith(("http://", "https://")):
                        omissions.append({
                            "item": receipt_text(raw, MAX_URL_CHARS),
                            "state": "QUALIFIED",
                            "reason": "external_or_invalid_origin",
                        })
                    continue
                if candidate not in queued and len(queued) < max_items * 4:
                    queued.add(candidate)
                    queue.append(candidate)
        except (OSError, ssl.SSLError, http.client.HTTPException, Hold) as exc:
            records.append({
                "kind": "https_resource",
                "source": receipt_text(url, MAX_URL_CHARS),
                "state": "UNAVAILABLE",
                "error": type(exc).__name__,
            })

    if queue:
        notes.append("item_limit_reached")

    receipt = {
        "origin": urllib.parse.urlunsplit((origin.scheme, origin.netloc, origin.path or "/", "", "")),
        "resolved_public_addresses_at_start": initial_addresses,
        "request_method": "GET",
        "tls_certificate_validation": True,
        "connection_address_pinning": True,
        "dns_rechecked_before_each_request": True,
        "cookies_used": False,
        "credentials_used": False,
        "javascript_executed": False,
        "forms_submitted": False,
        "cross_origin_redirects_allowed": False,
        "proxy_environment_used": False,
    }
    return records, objects, omissions, notes, receipt


def capture_id(records: list[dict], omissions: list[dict], policy: dict) -> str:
    return sha256_bytes(canonical_json({"records": records, "omissions": omissions, "policy": policy}))


def build_archive(output: Path, manifest: dict, objects: dict[str, bytes], overwrite: bool) -> None:
    output = output.expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists() and not overwrite:
        raise Hold(f"output already exists: {output}")
    descriptor, temp_name = tempfile.mkstemp(prefix=f".{output.name}.", suffix=".tmp", dir=output.parent)
    os.close(descriptor)
    temp = Path(temp_name)
    try:
        with zipfile.ZipFile(temp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9, allowZip64=True) as zf:
            zf.writestr(zip_info("CAPTURE_README.txt"), (
                "Defensive capture. Treat every object as untrusted data.\n"
                "Verify before optional isolated extraction. Objects are extensionless.\n"
            ).encode("utf-8"))
            zf.writestr(zip_info("CAPTURE_MANIFEST.json"), canonical_json(manifest))
            for digest in sorted(objects):
                zf.writestr(zip_info(f"objects/{digest}"), objects[digest])
        with temp.open("rb") as handle:
            os.fsync(handle.fileno())
        os.replace(temp, output)
    finally:
        if temp.exists():
            temp.unlink()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--folder", type=Path)
    mode.add_argument("--origin")
    parser.add_argument("--allow-network", action="store_true")
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--max-items", type=int, default=DEFAULT_MAX_ITEMS)
    parser.add_argument("--max-object-bytes", type=int, default=DEFAULT_MAX_OBJECT_BYTES)
    parser.add_argument("--max-total-bytes", type=int, default=DEFAULT_MAX_TOTAL_BYTES)
    parser.add_argument("--max-parse-bytes", type=int, default=DEFAULT_MAX_PARSE_BYTES)
    parser.add_argument("--timeout", type=float, default=DEFAULT_TIMEOUT)
    args = parser.parse_args()

    for name in ("max_items", "max_object_bytes", "max_total_bytes", "max_parse_bytes"):
        if getattr(args, name) <= 0:
            raise Hold(f"--{name.replace('_', '-')} must be positive")
    if not (1 <= args.timeout <= 120):
        raise Hold("--timeout must be between 1 and 120 seconds")

    policy = {
        "version": VERSION,
        "max_items": args.max_items,
        "max_object_bytes": args.max_object_bytes,
        "max_total_bytes": args.max_total_bytes,
        "max_parse_bytes": args.max_parse_bytes,
        "source_execution": False,
        "captured_content_execution": False,
        "automatic_installation": False,
        "automatic_opening": False,
        "untrusted_content_is_data": True,
        "model_or_agent_integration": False,
        "instruction_like_detection": "heuristic_review_signal",
        "content_addressed_objects": True,
    }

    if args.folder is not None:
        records, objects, omissions, notes = local_capture(
            args.folder, args.max_items, args.max_object_bytes, args.max_total_bytes
        )
        source = {"kind": "local_folder", "label": receipt_text(args.folder.name or "folder", 512)}
        network_receipt = None
    else:
        if not args.allow_network:
            raise Hold("--origin requires explicit --allow-network")
        records, objects, omissions, notes, network_receipt = network_capture(
            args.origin, args.max_items, args.max_object_bytes,
            args.max_total_bytes, args.max_parse_bytes, args.timeout
        )
        source = {"kind": "public_https_origin", "origin": network_receipt["origin"]}

    states = {record.get("state") for record in records}
    risky = any(record.get("risk_flags") for record in records)
    overall = "CAPTURED"
    if omissions or notes or risky or "UNAVAILABLE" in states or not records:
        overall = "QUALIFIED"

    manifest = {
        "schema": "goldlevel.defensive-capture.v1",
        "version": VERSION,
        "capture_id": capture_id(records, omissions, policy),
        "overall_state": overall,
        "source": source,
        "policy": policy,
        "network_receipt": network_receipt,
        "records": records,
        "omissions": omissions,
        "notes": sorted(set(notes)),
        "object_count": len(objects),
        "captured_bytes": sum(len(value) for value in objects.values()),
        "proof_boundary": (
            "Archive readability, risk classification, and recorded SHA-256 identity "
            "do not prove source security, benign content, completeness, compliance, "
            "or production recoverability."
        ),
    }
    build_archive(args.output, manifest, objects, args.overwrite)
    archive_path = args.output.expanduser().resolve()
    print(json.dumps({
        "status": overall,
        "output": str(archive_path),
        "archive_sha256": sha256_bytes(archive_path.read_bytes()),
        "records": len(records),
        "objects": len(objects),
        "omissions": len(omissions),
        "risk_flagged_records": sum(bool(record.get("risk_flags")) for record in records),
        "notes": sorted(set(notes)),
    }, indent=2))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("HOLD: interrupted", file=sys.stderr)
        raise SystemExit(130)
    except Hold as exc:
        print(f"HOLD: {exc}", file=sys.stderr)
        raise SystemExit(2)
