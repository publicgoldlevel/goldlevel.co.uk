# External assurance checklist

The public archive does not bundle an antivirus engine, current malware
signatures, YARA rules, or a behavioural sandbox.

Before site promotion, an operator should independently scan the plaintext
release ZIP and the extracted release directory with current local tools.

Record:

```text
scanner name and version
signature or rule-set date
exact target SHA-256
scan command
start and end time
result
quarantine or error state
```

The AES-256-GCM private-transport envelope is opaque to scanners until decrypted.
The decryption key must remain separate from both the website and the envelope.

A clean external result is additional evidence, not proof against every unknown
or future threat.
---

**Product:** GOLDLEVEL Defensive Archive Starter  
**Publisher:** GOLDLEVEL (Gold Level)  
**Version:** 2.0.0-rc1  
**Licence:** MIT  
**Copyright:** Copyright (c) 2026 GOLDLEVEL  
**Canonical route:** https://goldlevel.co.uk/download/goldlevel-defensive-archive-starter/  
**Artifact role:** EXTERNAL_ASSURANCE_CHECKLIST  
**Audience:** PUBLIC  
**Release state:** HARDENED_FULL_SPECTRUM_REVIEW_CANDIDATE

