# Signing-key continuity policy

    A signing key is a trust root, not disposable release metadata.

    This review candidate uses a provisional review key because the private key
    for the predecessor release was deliberately not exported. The candidate
    signature proves byte consistency against the included public key only.

    Before canonical public release:

    1. select an operator-controlled Ed25519 signing identity;
    2. protect the private key outside the release tree;
    3. rebuild every embedded fingerprint reference from that key;
    4. sign the exact final ZIP bytes;
    5. publish the public key and fingerprint separately;
    6. pin the fingerprint through an independent trusted route;
    7. preserve a key-rotation receipt when the trust root changes;
    8. never describe a bundled key as publisher identity by itself.

    Current candidate fingerprint:

    ```text
    9c2d0c40fe8b2c6c70f19cda0e00a78c0c1c47b500f4c21431b7c3947069f8b9
    ```

    Current signing state:

    ```text
    PROVISIONAL_REVIEW_KEY_REQUIRES_LOCAL_CANONICAL_REBUILD
    ```

---

**Product:** GOLDLEVEL Defensive Archive Starter  
**Publisher:** GOLDLEVEL (Gold Level)  
**Version:** 2.0.0-rc1  
**Licence:** MIT  
**Copyright:** Copyright (c) 2026 GOLDLEVEL  
**Canonical route:** https://goldlevel.co.uk/download/goldlevel-defensive-archive-starter/  
**Artifact role:** KEY_CONTINUITY_POLICY  
**Audience:** PUBLIC  
**Release state:** HARDENED_FULL_SPECTRUM_REVIEW_CANDIDATE
