# Threat model

## Covered by design

- archive path traversal and absolute paths;
- duplicate, case-fold, and Unicode-normalisation collisions;
- symbolic links and non-regular local objects;
- decompression bombs within declared limits;
- unsupported or encrypted ZIP members;
- common credential-like local filenames;
- accidental cross-origin crawling;
- private-address and loopback network targets;
- cross-origin redirects;
- automatic execution of captured material;
- control-character and bidirectional text manipulation in receipts;
- common executable, archive, active-document, active-web, test-signature,
  and instruction-like indicators;
- release tampering detectable through a pinned detached signature;
- private-transport tampering detectable through authenticated encryption.

## Residual risk

- unknown malicious formats or behaviour;
- content that evades heuristic classification;
- compromised operating system, Python interpreter, TLS trust store, or DNS;
- local directory races involving parent components;
- public-key substitution when the key is not pinned independently;
- operator error after extraction;
- false positives and false negatives.

Use this starter as one bounded evidence-preservation layer, not as a complete
security product.

## Additional threat surfaces

- source or predecessor substitution;
- identity and licence drift;
- wrapper-versus-payload confusion;
- signing-key substitution or silent rotation;
- post-review byte changes;
- reproducible compromised builds;
- dependency or external-tool drift;
- parser differential behaviour;
- encoded and disguised active content;
- missing-scanner false-clean results;
- source-upload authority injection;
- route, retirement and lifecycle drift;
- future threats absent from the current test corpus.

The release does not claim that these surfaces are eliminated.

---

**Product:** GOLDLEVEL Defensive Archive Starter  
**Publisher:** GOLDLEVEL (Gold Level)  
**Version:** 2.0.0-rc1  
**Licence:** MIT  
**Copyright:** Copyright (c) 2026 GOLDLEVEL  
**Canonical route:** https://goldlevel.co.uk/download/goldlevel-defensive-archive-starter/  
**Artifact role:** THREAT_MODEL  
**Audience:** PUBLIC  
**Release state:** HARDENED_FULL_SPECTRUM_REVIEW_CANDIDATE

