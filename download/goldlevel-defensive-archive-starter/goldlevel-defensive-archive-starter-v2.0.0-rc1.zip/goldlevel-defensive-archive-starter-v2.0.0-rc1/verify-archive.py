#!/usr/bin/env python3
# Product: GOLDLEVEL Defensive Archive Starter
# Publisher: GOLDLEVEL
# Version: 2.0.0-rc1
# Licence: MIT
# Copyright: Copyright (c) 2026 GOLDLEVEL
# Canonical route: https://goldlevel.co.uk/download/goldlevel-defensive-archive-starter/
# Release state: HARDENED_FULL_SPECTRUM_REVIEW_CANDIDATE
"""Validate a defensive capture ZIP without executing captured material."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import stat
import sys
import tempfile
import unicodedata
import zipfile
from pathlib import Path, PurePosixPath

ALLOWED_COMPRESSION = {zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED}
MAX_MEMBERS = 10000
MAX_TOTAL_BYTES = 500 * 1024 * 1024
MAX_MEMBER_BYTES = 100 * 1024 * 1024
MAX_RATIO = 1000.0
MAX_MANIFEST_BYTES = 10 * 1024 * 1024
MAX_RECORDS = 10000
MAX_OMISSIONS = 10000
MAX_NOTES = 2000
MAX_JSON_DEPTH = 64
REQUIRED_STATES = {"CAPTURED", "QUALIFIED", "UNAVAILABLE", "NOT_APPLICABLE", "REQUIRES_LOCAL_PROOF"}
RISK_FLAGS = {
    "standard_test_signature", "executable_signature", "archive_container",
    "nested_member_limit", "nested_size_limit", "macro_enabled_document",
    "embedded_object", "external_document_link", "active_document",
    "active_web_content", "disguised_active_content", "instruction_like_text",
    "opaque_binary_content",
    "suspicious_double_extension", "metadata_content_mismatch",
    "polyglot_signal", "nested_unsafe_path", "nested_duplicate_member",
    "nested_case_collision", "nested_unicode_collision", "nested_symlink",
    "nested_encrypted_member", "nested_decompression_ratio",
    "malformed_archive_container",
}


class Hold(RuntimeError):
    pass


def sha256_stream(handle) -> tuple[str, int]:
    digest = hashlib.sha256()
    total = 0
    while True:
        chunk = handle.read(1024 * 1024)
        if not chunk:
            break
        total += len(chunk)
        digest.update(chunk)
    return digest.hexdigest(), total


def safe_name(name: str) -> str:
    if not name or "\\" in name or "\x00" in name:
        raise Hold(f"unsafe ZIP path: {name!r}")
    path = PurePosixPath(name)
    if path.is_absolute() or any(part in {"", ".", ".."} for part in path.parts):
        raise Hold(f"unsafe ZIP path: {name!r}")
    normal = unicodedata.normalize("NFC", path.as_posix())
    if normal != path.as_posix():
        raise Hold(f"non-canonical Unicode ZIP path: {name!r}")
    return normal


def inspect_members(zf: zipfile.ZipFile) -> dict[str, zipfile.ZipInfo]:
    infos = zf.infolist()
    if not infos or len(infos) > MAX_MEMBERS:
        raise Hold("archive member count is outside policy")
    names: dict[str, zipfile.ZipInfo] = {}
    casefold: dict[str, str] = {}
    nfc: dict[str, str] = {}
    total = 0

    for info in infos:
        name = safe_name(info.filename)
        if name in names:
            raise Hold(f"duplicate ZIP member: {name}")
        if name.casefold() in casefold:
            raise Hold(f"case-fold collision: {casefold[name.casefold()]} and {name}")
        key = unicodedata.normalize("NFC", name)
        if key in nfc:
            raise Hold(f"Unicode-normalisation collision: {nfc[key]} and {name}")
        names[name] = info
        casefold[name.casefold()] = name
        nfc[key] = name

        mode = (info.external_attr >> 16) & 0xFFFF
        if stat.S_ISLNK(mode):
            raise Hold(f"symbolic link rejected: {name}")
        if info.flag_bits & 0x1:
            raise Hold(f"encrypted member rejected: {name}")
        if info.compress_type not in ALLOWED_COMPRESSION:
            raise Hold(f"unsupported compression method: {name}")
        if info.file_size > MAX_MEMBER_BYTES:
            raise Hold(f"member too large: {name}")
        total += info.file_size
        if total > MAX_TOTAL_BYTES:
            raise Hold("archive exceeds total uncompressed byte limit")
        ratio = info.file_size / max(info.compress_size, 1)
        if ratio > MAX_RATIO and info.file_size > 1024 * 1024:
            raise Hold(f"decompression ratio too high: {name}")

        if name not in {"CAPTURE_README.txt", "CAPTURE_MANIFEST.json"}:
            if not name.startswith("objects/"):
                raise Hold(f"unexpected archive member: {name}")
            digest = name.removeprefix("objects/")
            if len(digest) != 64 or any(char not in "0123456789abcdef" for char in digest):
                raise Hold(f"invalid content-addressed object name: {name}")
    return names



def json_depth(value: object, current: int = 0) -> int:
    if current > MAX_JSON_DEPTH:
        return current
    if isinstance(value, dict):
        if not value:
            return current + 1
        return max(json_depth(key, current + 1) for key in value.keys()) if False else max(
            [current + 1] + [json_depth(item, current + 1) for item in value.values()]
        )
    if isinstance(value, list):
        return max([current + 1] + [json_depth(item, current + 1) for item in value])
    return current + 1


def validate_manifest_bounds(manifest: dict) -> None:
    depth = json_depth(manifest)
    if depth > MAX_JSON_DEPTH:
        raise Hold(f"manifest nesting exceeds policy: {depth}")
    records = manifest.get("records")
    omissions = manifest.get("omissions")
    notes = manifest.get("notes")
    if not isinstance(records, list) or len(records) > MAX_RECORDS:
        raise Hold("manifest record count exceeds policy")
    if not isinstance(omissions, list) or len(omissions) > MAX_OMISSIONS:
        raise Hold("manifest omission count exceeds policy")
    if not isinstance(notes, list) or len(notes) > MAX_NOTES:
        raise Hold("manifest note count exceeds policy")
    if any(not isinstance(note, str) or len(note) > 8192 for note in notes):
        raise Hold("manifest note is invalid or too long")


def load_manifest(zf: zipfile.ZipFile, names: dict[str, zipfile.ZipInfo]) -> dict:
    if "CAPTURE_MANIFEST.json" not in names:
        raise Hold("CAPTURE_MANIFEST.json is missing")
    raw = zf.read("CAPTURE_MANIFEST.json")
    if len(raw) > MAX_MANIFEST_BYTES:
        raise Hold("manifest exceeds size policy")
    try:
        manifest = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise Hold(f"manifest is not valid UTF-8 JSON: {type(exc).__name__}") from exc
    if manifest.get("schema") != "goldlevel.defensive-capture.v1":
        raise Hold("unsupported manifest schema")
    if manifest.get("overall_state") not in REQUIRED_STATES:
        raise Hold("invalid overall evidence state")
    if not isinstance(manifest.get("records"), list):
        raise Hold("manifest records must be a list")
    if not isinstance(manifest.get("omissions"), list):
        raise Hold("manifest omissions must be a list")
    if not isinstance(manifest.get("policy"), dict):
        raise Hold("manifest policy must be an object")
    if manifest["policy"].get("captured_content_execution") is not False:
        raise Hold("manifest execution policy is not false")
    if manifest["policy"].get("model_or_agent_integration") is not False:
        raise Hold("manifest model or agent integration must be false")
    validate_manifest_bounds(manifest)
    return manifest


def verify_objects(zf: zipfile.ZipFile, names: dict[str, zipfile.ZipInfo], manifest: dict):
    verified = 0
    total = 0
    referenced: set[str] = set()
    source_records: set[tuple[str, str]] = set()
    flagged = 0

    for index, record in enumerate(manifest["records"]):
        if not isinstance(record, dict):
            raise Hold(f"record {index} is not an object")
        state = record.get("state")
        if state not in REQUIRED_STATES:
            raise Hold(f"record {index} has invalid state")
        source = record.get("source")
        if not isinstance(source, str) or len(source) > 8192:
            raise Hold(f"record {index} has invalid source")
        marker = (record.get("kind", ""), source)
        if marker in source_records:
            raise Hold(f"duplicate source record: {source}")
        source_records.add(marker)

        flags = record.get("risk_flags", [])
        if not isinstance(flags, list) or any(flag not in RISK_FLAGS for flag in flags):
            raise Hold(f"record {index} has invalid risk flags")
        if bool(flags) != bool(record.get("review_required")):
            raise Hold(f"record {index} review flag mismatch")
        flagged += bool(flags)

        if state != "CAPTURED":
            continue
        object_name = record.get("object")
        expected = record.get("sha256")
        expected_bytes = record.get("bytes")
        if not isinstance(object_name, str) or not object_name.startswith("objects/"):
            raise Hold(f"record {index} has invalid object path")
        object_name = safe_name(object_name)
        if object_name not in names:
            raise Hold(f"manifest object missing: {object_name}")
        if not isinstance(expected, str) or len(expected) != 64 or any(char not in "0123456789abcdef" for char in expected):
            raise Hold(f"record {index} has invalid SHA-256")
        if object_name != f"objects/{expected}":
            raise Hold(f"record {index} object name does not match SHA-256")
        if not isinstance(expected_bytes, int) or expected_bytes < 0:
            raise Hold(f"record {index} has invalid byte count")
        with zf.open(object_name, "r") as handle:
            actual, size = sha256_stream(handle)
        if actual != expected or size != expected_bytes:
            raise Hold(f"object mismatch: {object_name}")
        referenced.add(object_name)
        verified += 1
        total += size

    extra = sorted(name for name in names if name.startswith("objects/") and name not in referenced)
    if extra:
        raise Hold(f"unreferenced objects present: {extra[:3]}")
    if manifest.get("object_count") != len(referenced):
        raise Hold("manifest object_count mismatch")
    if manifest.get("captured_bytes") != total:
        raise Hold("manifest captured_bytes mismatch")
    return verified, total, flagged


def extract_isolated(archive: Path, destination: Path) -> None:
    destination = destination.expanduser().resolve()
    if destination.exists():
        raise Hold(f"extraction destination already exists: {destination}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = Path(tempfile.mkdtemp(prefix=f".{destination.name}.", dir=destination.parent))
    try:
        with zipfile.ZipFile(archive) as zf:
            names = inspect_members(zf)
            for name in sorted(names):
                target = temporary / name
                target.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(name, "r") as source, target.open("xb") as output:
                    shutil.copyfileobj(source, output, length=1024 * 1024)
        os.replace(temporary, destination)
    finally:
        if temporary.exists():
            shutil.rmtree(temporary)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    parser.add_argument("--extract-to", type=Path)
    parser.add_argument("--strict", action="store_true")
    args = parser.parse_args()

    archive = args.archive.expanduser().resolve()
    if not archive.is_file() or archive.is_symlink():
        raise Hold("archive must be a regular file")

    with zipfile.ZipFile(archive) as zf:
        bad = zf.testzip()
        if bad:
            raise Hold(f"CRC failure: {bad}")
        names = inspect_members(zf)
        manifest = load_manifest(zf, names)
        verified, total, flagged = verify_objects(zf, names, manifest)

    if args.strict and flagged:
        raise Hold(f"strict mode rejected {flagged} risk-flagged records")
    if args.extract_to:
        extract_isolated(archive, args.extract_to)

    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    print(json.dumps({
        "gate": "PASS",
        "archive": archive.name,
        "archive_sha256": digest,
        "members": len(names),
        "verified_objects": verified,
        "verified_object_bytes": total,
        "risk_flagged_records": flagged,
        "overall_state": manifest["overall_state"],
        "strict_mode": args.strict,
        "isolated_extraction": bool(args.extract_to),
        "proof_boundary": (
            "This proves archive readability and recorded object identity only; "
            "it does not prove security, benign content, completeness, compliance, "
            "or production recoverability."
        ),
    }, indent=2))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("HOLD: interrupted", file=sys.stderr)
        raise SystemExit(130)
    except (Hold, zipfile.BadZipFile) as exc:
        print(f"HOLD: {exc}", file=sys.stderr)
        raise SystemExit(2)
