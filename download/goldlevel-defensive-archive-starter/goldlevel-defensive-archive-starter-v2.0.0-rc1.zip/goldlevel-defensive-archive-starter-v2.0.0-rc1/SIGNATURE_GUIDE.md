# Release signature verification

    Keep these files together:

    - `goldlevel-defensive-archive-starter-v2.0.0-rc1.zip`
    - `goldlevel-defensive-archive-starter-v2.0.0-rc1.zip.ed25519`
    - `goldlevel-defensive-archive-starter-v2.0.0-rc1.release-public-key.pem`
    - `goldlevel-defensive-archive-starter-v2.0.0-rc1.release-key-fingerprint.txt`
    - `goldlevel-defensive-archive-starter-v2.0.0-rc1.zip.sha256`
    - `goldlevel-defensive-archive-starter-v2.0.0-rc1.zip.sha512`

    Verify the complete envelope:

    ```bash
    python3 verify-release-envelope.py \
      --payload goldlevel-defensive-archive-starter-v2.0.0-rc1.zip \
      --sha256 goldlevel-defensive-archive-starter-v2.0.0-rc1.zip.sha256 \
      --sha512 goldlevel-defensive-archive-starter-v2.0.0-rc1.zip.sha512 \
      --signature goldlevel-defensive-archive-starter-v2.0.0-rc1.zip.ed25519 \
      --public-key goldlevel-defensive-archive-starter-v2.0.0-rc1.release-public-key.pem \
      --fingerprint goldlevel-defensive-archive-starter-v2.0.0-rc1.release-key-fingerprint.txt
    ```

    OpenSSL 3 is used for Ed25519 verification. A successful signature check
    authenticates the ZIP only against the supplied public key. The final
    public key or fingerprint must be pinned through an independent trusted
    route before it is treated as publisher identity.

---

**Product:** GOLDLEVEL Defensive Archive Starter  
**Publisher:** GOLDLEVEL (Gold Level)  
**Version:** 2.0.0-rc1  
**Licence:** MIT  
**Copyright:** Copyright (c) 2026 GOLDLEVEL  
**Canonical route:** https://goldlevel.co.uk/download/goldlevel-defensive-archive-starter/  
**Artifact role:** SIGNATURE_GUIDE  
**Audience:** PUBLIC  
**Release state:** HARDENED_FULL_SPECTRUM_REVIEW_CANDIDATE
