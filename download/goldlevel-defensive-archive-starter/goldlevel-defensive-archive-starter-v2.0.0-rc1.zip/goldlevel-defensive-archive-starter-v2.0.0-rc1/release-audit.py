#!/usr/bin/env python3
# Product: GOLDLEVEL Defensive Archive Starter
# Publisher: GOLDLEVEL
# Version: 2.0.0-rc1
# Licence: MIT
# Copyright: Copyright (c) 2026 GOLDLEVEL
# Canonical route: https://goldlevel.co.uk/download/goldlevel-defensive-archive-starter/
# Release state: HARDENED_FULL_SPECTRUM_REVIEW_CANDIDATE
"""Audit an extracted release directory without executing captured content."""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
import re
import stat
import sys
import unicodedata
from pathlib import Path, PurePosixPath

SECRET_PATTERNS = (
    re.compile(rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    re.compile(rb"\bAKIA[0-9A-Z]{16}\b"),
    re.compile(rb"\bgh[pousr]_[A-Za-z0-9_]{30,}\b"),
    re.compile(rb"\bxox[baprs]-[A-Za-z0-9-]{20,}\b"),
)
MAX_RELEASE_FILES = 5000
MAX_MANIFEST_BYTES = 10 * 1024 * 1024
MAX_CHECKSUM_BYTES = 5 * 1024 * 1024
MAX_RECORDS = 5000
MAX_CHECKSUM_LINES = 5000

DANGEROUS_CALLS = {
    "eval", "exec", "__import__", "os.system", "os.popen",
    "subprocess.run", "subprocess.Popen", "subprocess.call",
    "pickle.loads", "marshal.loads",
}
EXTERNAL_TOOL_ALLOWLIST = {
    "verify-release-envelope.py": {"subprocess.run"},
}
REQUIRED_IDENTITY_FILES = {
    "ARTIFACT_IDENTITY.json",
    "PUBLIC_PROVENANCE.json",
    "INWARD_SECURITY_CONTRACT.json",
    "SECURITY_DIMENSION_MATRIX.json",
    "RELEASE_ENVELOPE_POLICY.json",
    "COMPONENT_BINDING.json",
    "BUILD_RECIPE.json",
    "RELEASE_PUBLIC_KEY.pem",
    "RELEASE_KEY_FINGERPRINT.txt",
    "LICENSE.txt",
    "NOTICE.md",
}


class Hold(RuntimeError):
    pass


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def safe_release_name(raw: object) -> str:
    if not isinstance(raw, str) or not raw or "\\" in raw or "\x00" in raw:
        raise Hold(f"unsafe release path: {raw!r}")
    if re.match(r"^[A-Za-z]:", raw):
        raise Hold(f"drive-qualified release path rejected: {raw!r}")
    path = PurePosixPath(raw)
    if path.is_absolute() or any(part in {"", ".", ".."} for part in path.parts):
        raise Hold(f"unsafe release path: {raw!r}")
    normal = unicodedata.normalize("NFC", path.as_posix())
    if normal != path.as_posix():
        raise Hold(f"non-canonical Unicode release path: {raw!r}")
    return normal


def confined_path(root: Path, raw: object) -> tuple[str, Path]:
    name = safe_release_name(raw)
    candidate = (root / name).resolve(strict=False)
    try:
        candidate.relative_to(root)
    except ValueError as exc:
        raise Hold(f"release path escapes root: {name!r}") from exc
    return name, candidate



def bounded_nodes(root: Path) -> list[Path]:
    nodes: list[Path] = []
    for base, dirs, files in os.walk(root, topdown=True, followlinks=False):
        base_path = Path(base)
        for name in sorted(dirs):
            nodes.append(base_path / name)
            if len(nodes) > MAX_RELEASE_FILES * 2:
                raise Hold("release filesystem object count exceeds policy")
        for name in sorted(files):
            nodes.append(base_path / name)
            if len(nodes) > MAX_RELEASE_FILES * 2:
                raise Hold("release filesystem object count exceeds policy")
    return nodes


def call_name(node: ast.Call) -> str:
    parts: list[str] = []
    current = node.func
    while isinstance(current, ast.Attribute):
        parts.append(current.attr)
        current = current.value
    if isinstance(current, ast.Name):
        parts.append(current.id)
    return ".".join(reversed(parts))


def collision_checked(names: list[str], label: str) -> None:
    exact: set[str] = set()
    folded: dict[str, str] = {}
    normalised: dict[str, str] = {}
    for name in names:
        if name in exact:
            raise Hold(f"duplicate {label} path: {name}")
        exact.add(name)
        fold = name.casefold()
        if fold in folded and folded[fold] != name:
            raise Hold(f"case-fold {label} collision: {folded[fold]} and {name}")
        folded[fold] = name
        nfc = unicodedata.normalize("NFC", name)
        if nfc in normalised and normalised[nfc] != name:
            raise Hold(f"Unicode {label} collision: {normalised[nfc]} and {name}")
        normalised[nfc] = name


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("release_dir", type=Path)
    args = parser.parse_args()
    root = args.release_dir.expanduser().resolve()
    if not root.is_dir() or root.is_symlink():
        raise Hold("release directory must be a real directory")

    manifest_path = root / "RELEASE_MANIFEST.json"
    sums_path = root / "SHA256SUMS.txt"
    if not manifest_path.is_file() or manifest_path.is_symlink():
        raise Hold("release manifest missing or unsafe")
    if not sums_path.is_file() or sums_path.is_symlink():
        raise Hold("checksum file missing or unsafe")

    if manifest_path.stat().st_size > MAX_MANIFEST_BYTES:
        raise Hold("release manifest exceeds size policy")
    if sums_path.stat().st_size > MAX_CHECKSUM_BYTES:
        raise Hold("checksum file exceeds size policy")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    records = manifest.get("records")
    if not isinstance(records, list):
        raise Hold("release records missing")
    if len(records) > MAX_RECORDS:
        raise Hold("release record count exceeds policy")

    all_nodes = bounded_nodes(root)
    if any(path.is_symlink() for path in all_nodes):
        raise Hold("symbolic link present")
    if any(path.exists() and not (path.is_file() or path.is_dir()) for path in all_nodes):
        raise Hold("non-regular filesystem object present")

    actual_files = sorted(
        path.relative_to(root).as_posix()
        for path in all_nodes
        if path.is_file()
    )

    record_names: list[str] = []
    record_paths: list[Path] = []
    for index, record in enumerate(records):
        if not isinstance(record, dict):
            raise Hold(f"manifest record {index} is not an object")
        name, path = confined_path(root, record.get("path"))
        record_names.append(name)
        record_paths.append(path)
    collision_checked(record_names, "manifest")

    for record, name, path in zip(records, record_names, record_paths):
        if not path.is_file() or path.is_symlink():
            raise Hold(f"manifest file missing or unsafe: {name}")
        if not isinstance(record.get("bytes"), int) or record["bytes"] < 0:
            raise Hold(f"invalid byte count: {name}")
        expected_hash = record.get("sha256")
        if not isinstance(expected_hash, str) or not re.fullmatch(r"[0-9a-f]{64}", expected_hash):
            raise Hold(f"invalid SHA-256: {name}")
        if path.stat().st_size != record["bytes"] or digest(path) != expected_hash:
            raise Hold(f"manifest mismatch: {name}")

    checksums: dict[str, str] = {}
    checksum_names: list[str] = []
    checksum_lines = sums_path.read_text(encoding="utf-8").splitlines()
    if len(checksum_lines) > MAX_CHECKSUM_LINES:
        raise Hold("checksum line count exceeds policy")
    for line_number, line in enumerate(checksum_lines, start=1):
        if not line.strip():
            continue
        try:
            value, raw_name = line.split("  ", 1)
        except ValueError as exc:
            raise Hold(f"malformed checksum line {line_number}") from exc
        if not re.fullmatch(r"[0-9a-f]{64}", value):
            raise Hold(f"invalid checksum on line {line_number}")
        name, path = confined_path(root, raw_name)
        checksum_names.append(name)
        if name in checksums:
            raise Hold(f"duplicate checksum path: {name}")
        checksums[name] = value
        if not path.is_file() or path.is_symlink() or digest(path) != value:
            raise Hold(f"checksum mismatch: {name}")
    collision_checked(checksum_names, "checksum")

    permitted = set(record_names) | {"RELEASE_MANIFEST.json", "SHA256SUMS.txt"}
    if set(actual_files) != permitted:
        raise Hold("unexpected or missing release files")

    missing_identity = sorted(REQUIRED_IDENTITY_FILES - set(actual_files))
    if missing_identity:
        raise Hold(f"required identity files missing: {missing_identity}")

    identity = json.loads(
        (root / "ARTIFACT_IDENTITY.json").read_text(encoding="utf-8")
    )
    expected_identity = {
        "product": "GOLDLEVEL Defensive Archive Starter",
        "publisher": "GOLDLEVEL",
        "version": manifest.get("version"),
        "license": "MIT",
        "copyright": "Copyright (c) 2026 GOLDLEVEL",
        "canonical_route": (
            "https://goldlevel.co.uk/download/"
            "goldlevel-defensive-archive-starter/"
        ),
    }
    for key, expected in expected_identity.items():
        if identity.get(key) != expected:
            raise Hold(f"identity mismatch for {key}")

    manifest_identity = manifest.get("identity")
    if not isinstance(manifest_identity, dict):
        raise Hold("manifest identity missing")
    for key, expected in expected_identity.items():
        actual = (
            manifest.get("version")
            if key == "version"
            else manifest_identity.get(key)
        )
        if actual != expected:
            raise Hold(f"manifest identity mismatch for {key}")

    binding = json.loads(
        (root / "COMPONENT_BINDING.json").read_text(encoding="utf-8")
    )
    binding_records = binding.get("records")
    if not isinstance(binding_records, list):
        raise Hold("component binding records missing")
    for record in binding_records:
        name, path = confined_path(root, record.get("path"))
        if not path.is_file() or path.is_symlink():
            raise Hold(f"bound component missing or unsafe: {name}")
        if (
            path.stat().st_size != record.get("bytes")
            or digest(path) != record.get("sha256")
        ):
            raise Hold(f"component binding mismatch: {name}")

    matrix = json.loads(
        (root / "SECURITY_DIMENSION_MATRIX.json").read_text(encoding="utf-8")
    )
    if matrix.get("dimensions") != 8 or matrix.get("stages") != 8:
        raise Hold("security dimension declaration mismatch")
    if len(matrix.get("matrix", [])) != 64:
        raise Hold("security dimension matrix must contain 64 cells")

    if any(
        name.endswith((".pyc", ".pyo"))
        or "/__pycache__/" in name
        or name.endswith((".DS_Store", "Thumbs.db"))
        for name in actual_files
    ):
        raise Hold("compiled bytecode or metadata residue present")

    secret_hits = []
    for relative in actual_files:
        _, path = confined_path(root, relative)
        data = path.read_bytes()
        if relative != "RELEASE_PUBLIC_KEY.pem" and any(pattern.search(data) for pattern in SECRET_PATTERNS):
            secret_hits.append(relative)
    if secret_hits:
        raise Hold(f"secret-like values present: {secret_hits}")

    scripts = {}
    for relative in sorted(name for name in actual_files if name.endswith(".py")):
        _, path = confined_path(root, relative)
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=relative)
        imports = sorted({
            alias.name.split(".", 1)[0]
            for node in ast.walk(tree)
            if isinstance(node, (ast.Import, ast.ImportFrom))
            for alias in (
                node.names if isinstance(node, ast.Import)
                else [ast.alias(name=node.module or "")]
            )
            if alias.name
        })
        calls = sorted({
            call_name(node)
            for node in ast.walk(tree)
            if isinstance(node, ast.Call) and call_name(node) in DANGEROUS_CALLS
        })
        allowed_calls = EXTERNAL_TOOL_ALLOWLIST.get(relative, set())
        disallowed = sorted(set(calls) - allowed_calls)
        if disallowed:
            raise Hold(f"dangerous calls in {relative}: {disallowed}")
        scripts[relative] = {
            "imports": imports,
            "dangerous_calls": calls,
            "allowed_external_calls": sorted(allowed_calls),
        }

    print(json.dumps({
        "gate": "PASS",
        "release_version": manifest.get("version"),
        "files": len(actual_files),
        "manifest_records": len(records),
        "component_records": len(binding_records),
        "security_dimension_cells": len(matrix.get("matrix", [])),
        "identity_consistency": "PASS",
        "path_confinement": "PASS",
        "manifest_collisions": "PASS",
        "checksum_collisions": "PASS",
        "secret_pattern_hits": secret_hits,
        "scripts": scripts,
        "authenticity_boundary": (
            "A detached signature proves consistency against a supplied public key. "
            "Publisher identity requires an independently pinned key or fingerprint."
        ),
        "proof_boundary": (
            "Static release checks do not guarantee absence of unknown malicious behaviour."
        ),
    }, indent=2))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (Hold, json.JSONDecodeError, SyntaxError, ValueError, OSError) as exc:
        print(f"HOLD: {exc}", file=sys.stderr)
        raise SystemExit(2)
