# Defensive testing boundary

The included adversarial tests operate only on synthetic local fixtures created
inside a temporary directory. They do not scan, probe, exploit, authenticate to,
or stress any live service.

The harness is intended to:

- cross archive and manifest boundaries with harmless synthetic inputs;
- verify fail-closed handling of malformed and hostile structures;
- exercise parser, content-classification, and resource limits;
- expose unresolved assurance gaps in a machine-readable report;
- preserve the default no-network posture.

It is not a penetration-testing toolkit and contains no exploit payloads,
credential attacks, persistence, evasion, remote command execution, denial of
service, or vulnerability scanning.

Use the `standard` profile for routine review. The `extended` profile increases
local synthetic workload but remains bounded.
---

**Product:** GOLDLEVEL Defensive Archive Starter  
**Publisher:** GOLDLEVEL (Gold Level)  
**Version:** 2.0.0-rc1  
**Licence:** MIT  
**Copyright:** Copyright (c) 2026 GOLDLEVEL  
**Canonical route:** https://goldlevel.co.uk/download/goldlevel-defensive-archive-starter/  
**Artifact role:** DEFENSIVE_TESTING_BOUNDARY  
**Audience:** PUBLIC  
**Release state:** HARDENED_FULL_SPECTRUM_REVIEW_CANDIDATE

