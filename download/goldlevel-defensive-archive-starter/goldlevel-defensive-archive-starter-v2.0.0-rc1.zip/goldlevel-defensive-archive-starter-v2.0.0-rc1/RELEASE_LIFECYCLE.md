# Release lifecycle

    ## States

    ```text
    DRAFT
    → INTERNAL_REVIEW
    → HARDENED_REVIEW_CANDIDATE
    → LOCAL_PROOF
    → HUMAN_RELEASE
    → PUBLIC
    → SUPERSEDED
    → RETIRED
    → CORRECTED
    ```

    A state may not be silently skipped.

    ## Correction

    A correction record should bind:

    - affected filename and version;
    - affected SHA-256 and SHA-512;
    - discovery date;
    - defect;
    - consequence;
    - replacement version;
    - replacement route;
    - key state;
    - rollback or retirement action.

    ## Retirement

    Retired files should leave the public tree when the replacement is ready,
    while a private retirement receipt preserves history and recovery pointers.

    ## Delivery

    A successful local build does not prove live delivery. Public verification
    requires route, status, redirect, delivered-byte and cache evidence.

---

**Product:** GOLDLEVEL Defensive Archive Starter  
**Publisher:** GOLDLEVEL (Gold Level)  
**Version:** 2.0.0-rc1  
**Licence:** MIT  
**Copyright:** Copyright (c) 2026 GOLDLEVEL  
**Canonical route:** https://goldlevel.co.uk/download/goldlevel-defensive-archive-starter/  
**Artifact role:** RELEASE_LIFECYCLE_GUIDE  
**Audience:** PUBLIC  
**Release state:** HARDENED_FULL_SPECTRUM_REVIEW_CANDIDATE
