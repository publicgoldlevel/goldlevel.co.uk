# Security boundary

## Enforced defaults

The starter is:

- read-only toward the selected source;
- offline unless network access is explicitly enabled;
- standard-library only for capture and verification;
- non-executing toward captured material;
- bounded by member, object, parsing, redirect, and total-byte limits;
- explicit about omissions, active content, instruction-like text, and proof gaps;
- content-addressed, with atomic output replacement;
- deterministic for the same source bytes, policy, and release.

## Untrusted material

Raw bytes are preserved without being treated as instructions. Receipt fields
are Unicode-normalised and stripped of control and bidirectional display
characters. Preserved object bytes are not rewritten.

Instruction-like text is detected heuristically after compatibility
normalisation, zero-width removal, markup separation, and punctuation folding.
Detection is a review signal, not proof of intent and not a complete defence
against every wording, encoding, language, or future mutation.

## Content-risk classification

The tools identify common executable signatures, archive containers, active
documents, active web content, and the standard antivirus test signature.
Risky objects remain extensionless and are never launched. This is static
classification, not an antivirus engine and not a guarantee against unknown
or newly developed attacks.

## Network boundary

Network mode requires `--allow-network`. Only public HTTPS origins are
accepted. Each request resolves the hostname, rejects non-public addresses,
and connects to one accepted address while TLS validates the requested
hostname. Redirects remain on the exact scheme, host, and port.

## Archive boundary

The verifier rejects unsafe paths, path collisions, symbolic links, encryption,
unsupported compression, extreme decompression ratios, unexpected members,
manifest inconsistencies, and object hash mismatches.

## Authenticity and confidential transport

The public release ZIP has a detached Ed25519 signature. Its public key must be
pinned independently on the publishing site. A separate AES-256-GCM envelope
may be used for private transport. Its key must never be published beside the
encrypted file.

## It does not prove

- that captured content is harmless;
- that every hidden instruction or malicious payload has been detected;
- that the source system is uncompromised;
- that a restore will be safe in production;
- that the operator device, Python runtime, DNS service, network, or trust
  store is trustworthy.

## Inward-security additions

The release now verifies consistency across identity, rights, provenance,
component binding, build recipe, release manifest, checksum manifest, key
fingerprint and route records.

The release also separates:

- source bytes from captured bytes;
- captured bytes from verification claims;
- inner payloads from outer packets;
- signature validity from publisher identity;
- local test results from external assurance;
- review candidates from public releases.

Encoded or disguised active-content review now considers UTF-8, UTF-16,
NUL-interleaved content, HTML entities, SVG foreign objects, data URIs,
inline-event markers, nested archive path defects, nested links, encryption,
collisions and decompression ratios.

These controls remain heuristic and bounded.

---

**Product:** GOLDLEVEL Defensive Archive Starter  
**Publisher:** GOLDLEVEL (Gold Level)  
**Version:** 2.0.0-rc1  
**Licence:** MIT  
**Copyright:** Copyright (c) 2026 GOLDLEVEL  
**Canonical route:** https://goldlevel.co.uk/download/goldlevel-defensive-archive-starter/  
**Artifact role:** SECURITY_BOUNDARY  
**Audience:** PUBLIC  
**Release state:** HARDENED_FULL_SPECTRUM_REVIEW_CANDIDATE

