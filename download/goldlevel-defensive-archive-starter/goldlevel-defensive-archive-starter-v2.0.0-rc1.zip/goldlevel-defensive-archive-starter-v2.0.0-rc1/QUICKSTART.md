# Quick start

    ## 1. Verify the release envelope

    ```bash
    python3 verify-release-envelope.py \
      --payload goldlevel-defensive-archive-starter-v2.0.0-rc1.zip \
      --sha256 goldlevel-defensive-archive-starter-v2.0.0-rc1.zip.sha256 \
      --sha512 goldlevel-defensive-archive-starter-v2.0.0-rc1.zip.sha512 \
      --signature goldlevel-defensive-archive-starter-v2.0.0-rc1.zip.ed25519 \
      --public-key goldlevel-defensive-archive-starter-v2.0.0-rc1.release-public-key.pem \
      --fingerprint goldlevel-defensive-archive-starter-v2.0.0-rc1.release-key-fingerprint.txt
    ```

    OpenSSL is required for Ed25519 verification. Without it, structural and
    checksum checks can run, but signature verification remains
    `REQUIRES_LOCAL_PROOF`.

    ## 2. Capture a local folder

    ```bash
    python3 capture-readonly.py \
      --folder ./public-export \
      --output ./public-export-capture.zip
    ```

    ## 3. Verify a capture

    ```bash
    python3 verify-archive.py ./public-export-capture.zip
    ```

    Strict mode rejects any flagged captured record:

    ```bash
    python3 verify-archive.py ./public-export-capture.zip --strict
    ```

    ## 4. Extract only to a new directory

    ```bash
    python3 verify-archive.py \
      ./public-export-capture.zip \
      --extract-to ./isolated-restore-test
    ```

    ## 5. Explicit HTTPS capture

    ```bash
    python3 capture-readonly.py \
      --origin https://example.org/ \
      --allow-network \
      --output ./example-org-capture.zip
    ```

    Remote capture is HTTPS-only, same-origin, public-address only and bounded.

    ## 6. Run local synthetic tests

    ```bash
    python3 tests/security-regression.py .
    python3 tests/adversarial-selftest.py . --profile standard
    python3 tests/security-dimension-selftest.py .
    python3 tests/provenance-selftest.py .
    python3 tests/release-envelope-selftest.py .
    ```

---

**Product:** GOLDLEVEL Defensive Archive Starter  
**Publisher:** GOLDLEVEL (Gold Level)  
**Version:** 2.0.0-rc1  
**Licence:** MIT  
**Copyright:** Copyright (c) 2026 GOLDLEVEL  
**Canonical route:** https://goldlevel.co.uk/download/goldlevel-defensive-archive-starter/  
**Artifact role:** QUICKSTART  
**Audience:** PUBLIC  
**Release state:** HARDENED_FULL_SPECTRUM_REVIEW_CANDIDATE
