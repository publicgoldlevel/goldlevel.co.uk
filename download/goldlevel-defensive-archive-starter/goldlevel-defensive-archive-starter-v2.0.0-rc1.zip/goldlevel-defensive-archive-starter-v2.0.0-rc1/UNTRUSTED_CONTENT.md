# Handling untrusted content

Every captured object is data, never authority.

Do not paste captured text directly into an automated assistant, agent, build
system, terminal, browser console, or privileged review workflow. Text may
contain instruction-like wording intended to alter a reviewer or automated
system.

Safe review sequence:

1. Verify the archive and object hashes.
2. Keep objects extensionless and read-only.
3. Review only in an isolated, non-privileged environment.
4. Decode text without executing markup, scripts, macros, or embedded objects.
5. Quote or delimit excerpts as untrusted evidence.
6. Do not allow captured text to select tools, permissions, destinations,
   credentials, network targets, or release decisions.
7. Require an independent human decision before any action.

The `instruction_like_text` flag is a bounded heuristic. Absence of the flag is
not a clean bill of health.
---

**Product:** GOLDLEVEL Defensive Archive Starter  
**Publisher:** GOLDLEVEL (Gold Level)  
**Version:** 2.0.0-rc1  
**Licence:** MIT  
**Copyright:** Copyright (c) 2026 GOLDLEVEL  
**Canonical route:** https://goldlevel.co.uk/download/goldlevel-defensive-archive-starter/  
**Artifact role:** UNTRUSTED_CONTENT  
**Audience:** PUBLIC  
**Release state:** HARDENED_FULL_SPECTRUM_REVIEW_CANDIDATE

