#!/usr/bin/env python3
# Product: GOLDLEVEL Defensive Archive Starter
# Publisher: GOLDLEVEL
# Version: 2.0.0-rc1
# Licence: MIT
# Copyright: Copyright (c) 2026 GOLDLEVEL
# Canonical route: https://goldlevel.co.uk/download/goldlevel-defensive-archive-starter/
"""Check completeness and uniqueness of the security-dimension matrix."""
from __future__ import annotations

import argparse
import json
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("release_dir", nargs="?", default=".", type=Path)
    args = parser.parse_args()
    root = args.release_dir.resolve()

    matrix = json.loads(
        (root / "SECURITY_DIMENSION_MATRIX.json").read_text(encoding="utf-8")
    )
    cells = matrix.get("matrix", [])
    pairs = {
        (item.get("dimension_id"), item.get("stage_id"))
        for item in cells
    }
    allowed_states = {
        "ENFORCED",
        "DOCUMENTED",
        "QUALIFIED",
        "REVIEW_REQUIRED",
        "REQUIRES_LOCAL_PROOF",
        "REQUIRES_INDEPENDENT_PIN",
        "HUMAN_RELEASE_REQUIRED",
    }
    passed = (
        matrix.get("dimensions") == 8
        and matrix.get("stages") == 8
        and matrix.get("cells") == 64
        and len(cells) == 64
        and len(pairs) == 64
        and all(item.get("state") in allowed_states for item in cells)
    )
    print(json.dumps({
        "gate": "PASS" if passed else "FAIL",
        "cells": len(cells),
        "unique_pairs": len(pairs),
        "states": sorted({item.get("state") for item in cells}),
        "universal_protection_claim": False,
    }, indent=2))
    return 0 if passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
