#!/usr/bin/env python3
# Product: GOLDLEVEL Defensive Archive Starter
# Publisher: GOLDLEVEL
# Version: 2.0.0-rc1
# Licence: MIT
# Copyright: Copyright (c) 2026 GOLDLEVEL
# Canonical route: https://goldlevel.co.uk/download/goldlevel-defensive-archive-starter/
"""Replay bounded release-envelope mutation tests."""
from __future__ import annotations

import argparse
import importlib.util
import json
import tempfile
from pathlib import Path


def load_module(path: Path):
    spec = importlib.util.spec_from_file_location(
        "release_envelope_under_test", path
    )
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("release_dir", nargs="?", default=".", type=Path)
    args = parser.parse_args()
    root = args.release_dir.resolve()
    module = load_module(root / "verify-release-envelope.py")

    results = []
    with tempfile.TemporaryDirectory() as name:
        temp = Path(name)

        good = temp / "sample.zip.sha256"
        good.write_text("a" * 64 + "  sample.zip\n", encoding="utf-8")
        try:
            value = module.read_sidecar(good, "sha256", "sample.zip")
            results.append({
                "id": "valid_sidecar_shape",
                "pass": value == "a" * 64,
            })
        except Exception:
            results.append({
                "id": "valid_sidecar_shape",
                "pass": False,
            })

        wrong_name = temp / "wrong-name.sha256"
        wrong_name.write_text(
            "a" * 64 + "  other.zip\n", encoding="utf-8"
        )
        try:
            module.read_sidecar(wrong_name, "sha256", "sample.zip")
        except module.Hold:
            results.append({
                "id": "wrong_sidecar_filename",
                "pass": True,
            })
        else:
            results.append({
                "id": "wrong_sidecar_filename",
                "pass": False,
            })

        malformed = temp / "malformed.sha256"
        malformed.write_text("not-a-sidecar\n", encoding="utf-8")
        try:
            module.read_sidecar(malformed, "sha256", "sample.zip")
        except module.Hold:
            results.append({
                "id": "malformed_sidecar",
                "pass": True,
            })
        else:
            results.append({
                "id": "malformed_sidecar",
                "pass": False,
            })

        for case_id, value in (
            ("parent_path", "../escape"),
            ("absolute_path", "/escape"),
            ("backslash_path", "..\\escape"),
            ("empty_path", ""),
        ):
            try:
                module.safe_name(value)
            except module.Hold:
                results.append({"id": case_id, "pass": True})
            else:
                results.append({"id": case_id, "pass": False})

    passed = all(item["pass"] for item in results)
    print(json.dumps({
        "gate": "PASS" if passed else "FAIL",
        "cases": results,
        "executed_external_tools": False,
    }, indent=2))
    return 0 if passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
