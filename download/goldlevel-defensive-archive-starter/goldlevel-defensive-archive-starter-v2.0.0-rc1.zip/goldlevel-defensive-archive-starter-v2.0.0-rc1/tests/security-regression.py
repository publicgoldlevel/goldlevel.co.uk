#!/usr/bin/env python3
# Product: GOLDLEVEL Defensive Archive Starter
# Publisher: GOLDLEVEL
# Version: 2.0.0-rc1
# Licence: MIT
# Copyright: Copyright (c) 2026 GOLDLEVEL
# Canonical route: https://goldlevel.co.uk/download/goldlevel-defensive-archive-starter/
# Release state: HARDENED_FULL_SPECTRUM_REVIEW_CANDIDATE
"""Replay the public security regression corpus."""
from __future__ import annotations

import argparse
import importlib.util
import json
import sys
import tempfile
from pathlib import Path


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("release_dir", nargs="?", default=".", type=Path)
    args = parser.parse_args()
    root = args.release_dir.resolve()
    capture = load_module(root / "capture-readonly.py", "capture_under_test")
    release_audit = load_module(root / "release-audit.py", "release_audit_under_test")

    corpus = json.loads((root / "tests" / "prompt-mutation-corpus.json").read_text(encoding="utf-8"))
    prompt_results = []
    for case in corpus:
        analysis = capture.instruction_analysis(case["input"].encode("utf-8"))
        actual = bool(analysis["detected"])
        prompt_results.append({
            "id": case["id"],
            "input": case["input"],
            "expected": case["expected"],
            "actual": actual,
            "score": analysis["score"],
            "signals": analysis["signals"],
            "pass": actual == case["expected"],
        })

    disguised = capture.classify_content(
        b"\x00\x01random-prefix<script>alert(1)</script>",
        "disguised.bin",
        "application/octet-stream",
    )
    disguised_pass = (
        "active_web_content" in disguised["risk_flags"]
        and "disguised_active_content" in disguised["risk_flags"]
        and disguised["review_required"] is True
    )

    with tempfile.TemporaryDirectory() as td:
        malicious = Path(td).resolve()
        try:
            release_audit.confined_path(malicious, "../outside-test-file")
        except release_audit.Hold as exc:
            path_confinement_pass = True
            path_confinement_receipt = str(exc)
        else:
            path_confinement_pass = False
            path_confinement_receipt = "unsafe path accepted"

    passed = (
        all(item["pass"] for item in prompt_results)
        and disguised_pass
        and path_confinement_pass
    )
    print(json.dumps({
        "gate": "PASS" if passed else "FAIL",
        "prompt_cases": prompt_results,
        "disguised_active_content": {
            "pass": disguised_pass,
            "classification": disguised,
        },
        "release_audit_path_confinement": {
            "pass": path_confinement_pass,
            "receipt": path_confinement_receipt,
        },
    }, indent=2, ensure_ascii=False))
    return 0 if passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
