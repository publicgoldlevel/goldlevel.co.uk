#!/usr/bin/env python3
# Product: GOLDLEVEL Defensive Archive Starter
# Publisher: GOLDLEVEL
# Version: 2.0.0-rc1
# Licence: MIT
# Copyright: Copyright (c) 2026 GOLDLEVEL
# Canonical route: https://goldlevel.co.uk/download/goldlevel-defensive-archive-starter/
"""Check public identity, predecessor and provenance consistency."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

EXPECTED_SOURCE_SHA256 = 'fde36977f5af75802ce4fa8bef6c087429f4dc6e461d6d28476a9cc4d4ebf9e8'


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("release_dir", nargs="?", default=".", type=Path)
    args = parser.parse_args()
    root = args.release_dir.resolve()

    identity = json.loads(
        (root / "ARTIFACT_IDENTITY.json").read_text(encoding="utf-8")
    )
    provenance = json.loads(
        (root / "PUBLIC_PROVENANCE.json").read_text(encoding="utf-8")
    )
    recipe = json.loads(
        (root / "BUILD_RECIPE.json").read_text(encoding="utf-8")
    )
    policy = json.loads(
        (root / "RELEASE_ENVELOPE_POLICY.json").read_text(encoding="utf-8")
    )

    expected = {
        "product": 'GOLDLEVEL Defensive Archive Starter',
        "publisher": 'GOLDLEVEL',
        "version": '2.0.0-rc1',
        "license": 'MIT',
        "copyright": 'Copyright (c) 2026 GOLDLEVEL',
        "canonical_route": 'https://goldlevel.co.uk/download/goldlevel-defensive-archive-starter/',
    }

    passed = all(identity.get(key) == value for key, value in expected.items())
    passed = (
        passed
        and provenance.get("predecessor", {}).get("sha256")
        == EXPECTED_SOURCE_SHA256
    )
    passed = (
        passed
        and recipe.get("source", {}).get("sha256")
        == EXPECTED_SOURCE_SHA256
    )
    passed = (
        passed
        and policy.get("promotion_rule") == "HUMAN_RELEASE_REQUIRED"
    )

    print(json.dumps({
        "gate": "PASS" if passed else "FAIL",
        "identity": expected,
        "predecessor_sha256": EXPECTED_SOURCE_SHA256,
        "human_release_required": True,
    }, indent=2))
    return 0 if passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
