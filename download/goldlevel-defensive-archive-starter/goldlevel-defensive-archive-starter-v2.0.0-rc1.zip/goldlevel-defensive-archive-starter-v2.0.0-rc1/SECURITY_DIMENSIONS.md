# Security dimensions

    The starter now reviews eight security dimensions across eight lifecycle
    stages.

    ## Dimensions

    1. identity and rights;
    2. source and provenance;
    3. archive structure and parser safety;
    4. execution and authority boundaries;
    5. content and semantic risk;
    6. authenticity and supply chain;
    7. environment and transfer;
    8. lifecycle, correction and recovery.

    ## Lifecycle stages

    1. source intake;
    2. capture;
    3. object storage;
    4. manifesting;
    5. verification;
    6. isolated extraction;
    7. release packaging;
    8. downstream upload or use.

    The machine-readable matrix contains sixty-four cells. A cell may be
    `ENFORCED`, `DOCUMENTED`, `QUALIFIED`, `REVIEW_REQUIRED`,
    `REQUIRES_LOCAL_PROOF`, `REQUIRES_INDEPENDENT_PIN`, or
    `HUMAN_RELEASE_REQUIRED`.

    A larger matrix is not automatically stronger security. Its value is that
    omitted faces and proof gaps remain visible.

---

**Product:** GOLDLEVEL Defensive Archive Starter  
**Publisher:** GOLDLEVEL (Gold Level)  
**Version:** 2.0.0-rc1  
**Licence:** MIT  
**Copyright:** Copyright (c) 2026 GOLDLEVEL  
**Canonical route:** https://goldlevel.co.uk/download/goldlevel-defensive-archive-starter/  
**Artifact role:** SECURITY_DIMENSIONS_GUIDE  
**Audience:** PUBLIC  
**Release state:** HARDENED_FULL_SPECTRUM_REVIEW_CANDIDATE
