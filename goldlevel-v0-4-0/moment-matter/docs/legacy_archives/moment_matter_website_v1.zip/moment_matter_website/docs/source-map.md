# Website Source Map

## Commercial positioning

Public headline: Art prints, cards, and gifts for meaningful moments.

Public subhead: Thoughtful visual pieces for new beginnings, difficult seasons, personal milestones, calm rooms, and gifts that need more than ordinary words.

Simplest brand description: A collection of art prints, cards, and gift pieces made for people, homes, workspaces, and moments that matter.

## Product architecture

1. Meaningful Cards — £5–£12
2. Gift Prints — £25–£75
3. Calm Room Prints — £35–£120
4. Paired Prints — £65–£145
5. Boxed Art Set — £95–£195
6. Art for Professional Spaces — from £250

## Public language safety

Use shop-normal wording. Keep deeper symbolic language inside artwork notes, packaging inserts, collector notes, or longer writing, not the first buying surface.

## Payment implementation notes

For Stripe Checkout, add a backend endpoint or serverless function to create Checkout Sessions and redirect from `checkout.html`.

For Shopify, replace the local basket with Shopify Buy Buttons or use product links.

For low-friction launch, create Stripe payment links for each product family and replace `Add to basket` with product-specific payment link buttons.
