# Moment & Matter — Website Release ZIP

Static commercial website for a mainstream shop front: art prints, cards, thoughtful gifts, calm room pieces, paired sets, boxed collections, and professional space enquiries.

## Open locally

Open `index.html` in a browser. No build step is required.

## Included pages

- `index.html` — landing page / public front door
- `shop.html` — product listing with category filters and search
- `product.html?id=...` — dynamic product page using `assets/data/products.js`
- `cart.html` — local basket using browser localStorage
- `checkout.html` — static checkout demonstration
- `thank-you.html` — static confirmation page
- `gift-guide.html` — occasion-based product selector
- `spaces.html` — professional spaces enquiry route
- `about.html`, `faq.html`, `contact.html`, `terms.html`, `privacy.html`

## Purchase pipeline state

The basket, product pages, and checkout flow are functional as a static prototype. They do **not** take real payment. Before launch, connect one of:

1. Stripe Checkout/payment links
2. Shopify Buy Button or full Shopify checkout
3. WooCommerce
4. PayPal checkout
5. Form + invoice workflow for professional spaces

## Product data

Edit products in:

```text
assets/data/products.js
```

Replace placeholder email `hello@example.com` with the live email address across `contact.html`, `spaces.html`, and visible policy text.

## Artwork

The current images are abstract SVG placeholders created for the site. Replace files in `assets/img/` with final artwork exports, or update the product data filenames.

## Public language lock

The front window uses mainstream product language:

- meaningful art prints
- thoughtful gifts
- art for calm spaces
- cards for moments that matter
- prints for new beginnings
- homes, desks, studios, quiet rooms
- made to be kept, framed, gifted, or displayed

Avoid public-surface language that makes the shop feel obscure, mystical, or over-internal.
