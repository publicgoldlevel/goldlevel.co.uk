window.PRODUCTS = [
  {
    "id": "card-words-hard",
    "category": "cards",
    "title": "When Words Are Hard Card",
    "subtitle": "A meaningful card for grief, apology, encouragement, or care.",
    "price": 6,
    "priceLabel": "\u00a36",
    "variant": "A6 folded card",
    "image": "art-01.svg",
    "bestFor": [
      "Grief",
      "Apology",
      "Encouragement",
      "Friendship",
      "Care packages"
    ],
    "arrives": [
      "A6 folded card",
      "Blank inside",
      "Recycled envelope",
      "Optional printed gift note"
    ],
    "description": "A quiet card for moments when ordinary wording feels too thin. Made to be easy to give and meaningful without needing a long explanation.",
    "badge": "Best seller"
  },
  {
    "id": "card-new-chapter",
    "category": "cards",
    "title": "New Chapter Card",
    "subtitle": "A simple card for beginnings, endings, moves, and fresh starts.",
    "price": 6,
    "priceLabel": "\u00a36",
    "variant": "A6 folded card",
    "image": "art-02.svg",
    "bestFor": [
      "New homes",
      "New jobs",
      "Fresh starts",
      "Endings",
      "Personal milestones"
    ],
    "arrives": [
      "A6 folded card",
      "Blank inside",
      "Recycled envelope",
      "Optional printed gift note"
    ],
    "description": "For the person stepping into something different. Calm, sincere, and easy to keep.",
    "badge": "Giftable"
  },
  {
    "id": "card-quiet-support",
    "category": "cards",
    "title": "Quiet Support Card",
    "subtitle": "A thoughtful card for difficult seasons and steady encouragement.",
    "price": 6,
    "priceLabel": "\u00a36",
    "variant": "A6 folded card",
    "image": "art-03.svg",
    "bestFor": [
      "Difficult seasons",
      "Recovery",
      "Encouragement",
      "Friendship",
      "Long-distance care"
    ],
    "arrives": [
      "A6 folded card",
      "Blank inside",
      "Recycled envelope",
      "Optional printed gift note"
    ],
    "description": "Designed for the kind of support that does not over-speak. A card that simply arrives and stays useful.",
    "badge": "New"
  },
  {
    "id": "print-quiet-beginning",
    "category": "gift-prints",
    "title": "Meaningful Art Print \u2014 Quiet Beginning",
    "subtitle": "A thoughtful art print for calm spaces, personal milestones, and meaningful gifts.",
    "price": 45,
    "priceLabel": "\u00a345",
    "variant": "A4 unframed print",
    "image": "art-04.svg",
    "bestFor": [
      "Thoughtful gifts",
      "New beginnings",
      "Desk spaces",
      "Bedrooms",
      "Friendship"
    ],
    "arrives": [
      "One A4 art print",
      "Carefully packaged",
      "Optional gift note",
      "Personal-use only"
    ],
    "description": "This print is made for moments that deserve something quieter and more lasting than ordinary words. It can be placed by a bed, above a desk, in an entryway, in a studio, or given as a thoughtful gift to someone going through a new chapter.",
    "badge": "A4"
  },
  {
    "id": "print-somewhere-to-land",
    "category": "gift-prints",
    "title": "Meaningful Art Print \u2014 Somewhere to Land",
    "subtitle": "A grounding print for someone moving through change.",
    "price": 55,
    "priceLabel": "\u00a355",
    "variant": "A3 unframed print",
    "image": "art-05.svg",
    "bestFor": [
      "Difficult seasons",
      "Moving home",
      "Recovery",
      "Personal milestones",
      "Gifts when words are hard"
    ],
    "arrives": [
      "One A3 art print",
      "Carefully packaged",
      "Optional gift note",
      "Personal-use only"
    ],
    "description": "A thoughtful piece for bedrooms, desks, entryways, studios, and quiet corners. Printed with care and designed to be kept, framed, gifted, or returned to over time.",
    "badge": "A3"
  },
  {
    "id": "print-warm-light",
    "category": "room-prints",
    "title": "Calm Room Print \u2014 Warm Light",
    "subtitle": "Calming art for bedrooms, desks, studios, and quiet rooms.",
    "price": 75,
    "priceLabel": "\u00a375",
    "variant": "A3 fine art print",
    "image": "art-06.svg",
    "bestFor": [
      "Calm bedrooms",
      "Entryways",
      "Home studios",
      "Quiet corners",
      "Personal reset spaces"
    ],
    "arrives": [
      "One A3 fine art print",
      "Carefully packaged",
      "Optional gift note",
      "Personal-use only"
    ],
    "description": "A simple visual piece for creating a more grounded, thoughtful atmosphere at home or work. Designed to sit quietly in the room rather than dominate it.",
    "badge": "Room print"
  },
  {
    "id": "print-still-water",
    "category": "room-prints",
    "title": "Calm Room Print \u2014 Still Water",
    "subtitle": "A minimal print for quiet corners, desks, and reflective spaces.",
    "price": 90,
    "priceLabel": "\u00a390",
    "variant": "A2 fine art print",
    "image": "art-07.svg",
    "bestFor": [
      "Quiet rooms",
      "Therapy rooms",
      "Home offices",
      "Studios",
      "Slow mornings"
    ],
    "arrives": [
      "One A2 fine art print",
      "Carefully packaged",
      "Optional gift note",
      "Personal-use only"
    ],
    "description": "Made for spaces where the eye needs somewhere calm to rest. Suitable for personal rooms and professional interiors.",
    "badge": "A2"
  },
  {
    "id": "paired-shared-light",
    "category": "paired-prints",
    "title": "Paired Print Set \u2014 Shared Light",
    "subtitle": "A two-piece art set for couples, friends, and shared spaces.",
    "price": 110,
    "priceLabel": "\u00a3110",
    "variant": "Two A4 prints",
    "image": "art-08.svg",
    "bestFor": [
      "Anniversaries",
      "Weddings",
      "Friendship",
      "Moving in",
      "Shared chapters"
    ],
    "arrives": [
      "Two A4 art prints",
      "Carefully packaged together",
      "Optional gift note",
      "Personal-use only"
    ],
    "description": "A thoughtful paired set for two people, one home, or a shared chapter. Designed to work as a pair or as two separate pieces that still speak to each other.",
    "badge": "Paired set"
  },
  {
    "id": "paired-two-quiet-places",
    "category": "paired-prints",
    "title": "Paired Print Set \u2014 Two Quiet Places",
    "subtitle": "A gentle two-piece set for shared homes and meaningful gifts.",
    "price": 125,
    "priceLabel": "\u00a3125",
    "variant": "Two A3 prints",
    "image": "art-09.svg",
    "bestFor": [
      "Couples",
      "Close friends",
      "Reconciliation",
      "New homes",
      "Shared studios"
    ],
    "arrives": [
      "Two A3 art prints",
      "Carefully packaged together",
      "Optional gift note",
      "Personal-use only"
    ],
    "description": "Two related pieces designed for homes, desks, studios, and calm rooms where the relationship between pieces matters as much as each print alone.",
    "badge": "Premium pair"
  },
  {
    "id": "boxed-meaningful-moments",
    "category": "boxed-sets",
    "title": "Boxed Art Set \u2014 Meaningful Moments",
    "subtitle": "A boxed set of small art prints for reflection, gifting, and display.",
    "price": 155,
    "priceLabel": "\u00a3155",
    "variant": "12 small prints in box",
    "image": "art-10.svg",
    "bestFor": [
      "Gifting",
      "Reflection",
      "Small frames",
      "Rotating displays",
      "Thoughtful keepsakes"
    ],
    "arrives": [
      "Twelve small art prints",
      "Boxed packaging",
      "Optional gift note",
      "Personal-use only"
    ],
    "description": "A collection of pieces that can be framed, rotated, kept, or given individually. Made for meaningful moments and calm spaces.",
    "badge": "Boxed set"
  },
  {
    "id": "space-calm-set",
    "category": "professional-spaces",
    "title": "Professional Space Set \u2014 Calm Room Starter",
    "subtitle": "A curated print set for studios, therapy rooms, offices, and retreats.",
    "price": 250,
    "priceLabel": "from \u00a3250",
    "variant": "Curated set by enquiry",
    "image": "art-11.svg",
    "bestFor": [
      "Therapy rooms",
      "Studios",
      "Wellness spaces",
      "Offices",
      "Waiting rooms"
    ],
    "arrives": [
      "Curated print set proposal",
      "Size options",
      "Room placement guidance",
      "Commercial-use quote if needed"
    ],
    "description": "For spaces where people come to think, talk, reset, wait, work, or feel calm. Enquire with photos or notes about your room and receive a proportionate recommendation.",
    "badge": "Enquiry"
  },
  {
    "id": "licence-calm-imagery",
    "category": "professional-spaces",
    "title": "Licensed Calm Imagery \u2014 Editorial / Space Use",
    "subtitle": "Licensing options for professional interiors, publications, and brand-aligned use.",
    "price": 450,
    "priceLabel": "from \u00a3450",
    "variant": "Licence by enquiry",
    "image": "art-12.svg",
    "bestFor": [
      "Professional interiors",
      "Retreat materials",
      "Editorial features",
      "Wellbeing publications",
      "Brand-aligned visual use"
    ],
    "arrives": [
      "Licence scope discussion",
      "Usage quote",
      "Image selection",
      "Written terms"
    ],
    "description": "For professional spaces and materials that need meaningful, calm visual work without generic stock imagery. Licence terms are quoted by usage and duration.",
    "badge": "Licence"
  }
];
window.CATEGORIES = [
  {
    "id": "cards",
    "title": "Meaningful Cards",
    "plain": "Meaningful cards for moments that matter.",
    "description": "For birthdays, grief, apology, friendship, encouragement, new homes, endings, beginnings, and times when ordinary cards feel too generic.",
    "price": "\u00a35\u2013\u00a312",
    "cta": "Shop cards",
    "href": "shop.html?category=cards",
    "need": "For a gift"
  },
  {
    "id": "gift-prints",
    "title": "Gift Prints",
    "plain": "Art prints designed as thoughtful gifts.",
    "description": "For someone starting over, moving home, recovering, grieving, building, or entering a new chapter.",
    "price": "\u00a325\u2013\u00a375",
    "cta": "Shop gift prints",
    "href": "shop.html?category=gift-prints",
    "need": "For a gift"
  },
  {
    "id": "room-prints",
    "title": "Calm Room Prints",
    "plain": "Calming art prints for bedrooms, desks, studios, and quiet spaces.",
    "description": "Simple visual pieces for creating a more grounded, thoughtful atmosphere at home or work.",
    "price": "\u00a335\u2013\u00a3120",
    "cta": "Shop room prints",
    "href": "shop.html?category=room-prints",
    "need": "For your home"
  },
  {
    "id": "paired-prints",
    "title": "Paired Prints",
    "plain": "Two-piece art sets for couples, friends, and shared spaces.",
    "description": "A thoughtful gift for anniversaries, weddings, friendship, reconciliation, moving in, or marking a shared chapter.",
    "price": "\u00a365\u2013\u00a3145",
    "cta": "Shop paired prints",
    "href": "shop.html?category=paired-prints",
    "need": "For shared spaces"
  },
  {
    "id": "boxed-sets",
    "title": "Boxed Art Set",
    "plain": "A boxed set of small art prints for reflection, gifting, and display.",
    "description": "A collection of pieces that can be framed, rotated, kept, or given individually.",
    "price": "\u00a395\u2013\u00a3195",
    "cta": "Shop boxed sets",
    "href": "shop.html?category=boxed-sets",
    "need": "For a meaningful set"
  },
  {
    "id": "professional-spaces",
    "title": "Art for Professional Spaces",
    "plain": "Art for studios, therapy rooms, wellness spaces, offices, and retreats.",
    "description": "Curated print sets for spaces where people come to think, talk, reset, wait, work, or feel calm.",
    "price": "from \u00a3250",
    "cta": "Enquire for your space",
    "href": "spaces.html",
    "need": "For professional spaces"
  }
];
