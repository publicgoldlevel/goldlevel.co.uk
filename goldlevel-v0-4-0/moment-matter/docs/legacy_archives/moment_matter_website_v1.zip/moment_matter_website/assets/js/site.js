
(function(){
  const $ = (sel, root=document) => root.querySelector(sel);
  const $$ = (sel, root=document) => Array.from(root.querySelectorAll(sel));
  const money = n => '£' + Number(n || 0).toFixed(0);
  const getCart = () => JSON.parse(localStorage.getItem('mm_cart') || '[]');
  const setCart = cart => { localStorage.setItem('mm_cart', JSON.stringify(cart)); updateCartCount(); };
  const findProduct = id => (window.PRODUCTS || []).find(p => p.id === id);
  function toast(message){
    let t = $('#toast'); if(!t){t=document.createElement('div'); t.id='toast'; t.className='toast'; document.body.appendChild(t);} t.textContent=message; t.classList.add('show'); setTimeout(()=>t.classList.remove('show'),1800);
  }
  function updateCartCount(){ const count = getCart().reduce((a,i)=>a+i.qty,0); $$('.cart-count').forEach(el=>el.textContent=count); }
  function addToCart(id, qty=1){ const p=findProduct(id); if(!p) return; const cart=getCart(); const existing=cart.find(i=>i.id===id); if(existing){existing.qty += qty}else{cart.push({id,qty})} setCart(cart); toast('Added to basket'); }
  function removeFromCart(id){ setCart(getCart().filter(i=>i.id!==id)); renderCart(); renderCheckoutSummary(); }
  function changeQty(id, delta){ const cart=getCart(); const item=cart.find(i=>i.id===id); if(!item) return; item.qty += delta; if(item.qty<=0){setCart(cart.filter(i=>i.id!==id))} else setCart(cart); renderCart(); renderCheckoutSummary(); }
  window.MM = {addToCart, removeFromCart, changeQty, getCart};

  function productCard(p){
    return `<article class="product-card" data-category="${p.category}" data-title="${p.title.toLowerCase()}">
      <a class="product-media" href="product.html?id=${p.id}" aria-label="View ${p.title}"><img src="assets/img/${p.image}" alt="Abstract artwork preview for ${p.title}"></a>
      <div class="product-body">
        <span class="badge">${p.badge || 'Artwork'}</span>
        <a class="product-title" href="product.html?id=${p.id}">${p.title}</a>
        <p class="product-meta">${p.subtitle}</p>
        <div class="product-foot"><strong>${p.priceLabel}</strong><button class="btn btn-secondary" data-add="${p.id}">Add to basket</button></div>
      </div>
    </article>`;
  }
  function renderFeatured(){
    const el=$('[data-featured-products]'); if(!el || !window.PRODUCTS) return;
    el.innerHTML = window.PRODUCTS.slice(0,6).map(productCard).join('');
  }
  function renderShop(){
    const grid=$('[data-product-grid]'); if(!grid || !window.PRODUCTS) return;
    grid.innerHTML=window.PRODUCTS.map(productCard).join('');
    const urlCat = new URLSearchParams(location.search).get('category') || 'all';
    setFilter(urlCat);
  }
  function setFilter(cat){
    $$('.filter-btn').forEach(btn=>btn.classList.toggle('active',btn.dataset.filter===cat));
    $$('.product-card').forEach(card=>{card.hidden = !(cat==='all' || card.dataset.category===cat);});
  }
  function renderProduct(){
    const mount=$('[data-product-detail]'); if(!mount || !window.PRODUCTS) return;
    const id = new URLSearchParams(location.search).get('id') || window.PRODUCTS[0].id;
    const p=findProduct(id);
    if(!p){ mount.innerHTML='<div class="empty-state"><h1>Product not found</h1><a class="btn btn-primary" href="shop.html">Back to shop</a></div>'; return; }
    document.title = `${p.title} | Moment & Matter`;
    const cat = (window.CATEGORIES || []).find(c=>c.id===p.category);
    mount.innerHTML=`<div class="breadcrumb"><a href="shop.html">Shop</a> / <a href="shop.html?category=${p.category}">${cat ? cat.title : 'Products'}</a></div>
      <div class="product-detail">
        <div class="detail-image"><img src="assets/img/${p.image}" alt="Abstract artwork preview for ${p.title}"></div>
        <article class="detail-panel">
          <span class="badge">${p.badge || 'Artwork'}</span>
          <h1 class="detail-title">${p.title}</h1>
          <p class="lede">${p.subtitle}</p>
          <div class="detail-price">${p.priceLabel}</div>
          <p>${p.description}</p>
          <div class="option-row"><span class="option">${p.variant}</span><span class="option">Optional gift note</span><span class="option">Carefully packaged</span></div>
          <div class="actions"><button class="btn btn-primary" data-add="${p.id}">Add to basket</button><a class="btn btn-secondary" href="checkout.html?buy=${p.id}">Buy now</a></div>
          <div class="grid-2" style="margin-top:26px">
            <div class="card"><h3>Best for</h3><ul class="list-clean">${p.bestFor.map(x=>`<li>${x}</li>`).join('')}</ul></div>
            <div class="card"><h3>What arrives</h3><ul class="list-clean">${p.arrives.map(x=>`<li>${x}</li>`).join('')}</ul></div>
          </div>
        </article>
      </div>`;
    const related=$('[data-related-products]');
    if(related){related.innerHTML=window.PRODUCTS.filter(x=>x.category===p.category && x.id!==p.id).slice(0,3).map(productCard).join('') || window.PRODUCTS.filter(x=>x.id!==p.id).slice(0,3).map(productCard).join('');}
  }
  function cartTotals(){ const items=getCart().map(i=>({ ...i, product: findProduct(i.id)})).filter(i=>i.product); const subtotal=items.reduce((a,i)=>a+i.product.price*i.qty,0); const shipping=subtotal>0 && subtotal<95 ? 4 : 0; const total=subtotal+shipping; return {items,subtotal,shipping,total}; }
  function renderCart(){
    const el=$('[data-cart]'); if(!el) return;
    const {items,subtotal,shipping,total}=cartTotals();
    if(!items.length){el.innerHTML=`<div class="empty-state card"><h1>Your basket is empty.</h1><p class="muted">Add a card, print, set, or space enquiry to begin.</p><a href="shop.html" class="btn btn-primary">Shop now</a></div>`; const s=$('[data-cart-summary]'); if(s) s.innerHTML=''; return;}
    el.innerHTML=items.map(i=>`<div class="cart-item"><img src="assets/img/${i.product.image}" alt=""><div><strong>${i.product.title}</strong><div class="muted small">${i.product.variant}</div><div class="qty-controls" aria-label="Quantity controls"><button onclick="MM.changeQty('${i.id}',-1)">−</button><span>${i.qty}</span><button onclick="MM.changeQty('${i.id}',1)">+</button><button onclick="MM.removeFromCart('${i.id}')">Remove</button></div></div><strong class="line-total">${money(i.product.price*i.qty)}</strong></div>`).join('');
    const s=$('[data-cart-summary]'); if(s) s.innerHTML=summaryHtml(subtotal,shipping,total,'checkout.html','Checkout');
  }
  function summaryHtml(subtotal,shipping,total,href,label){ return `<div class="checkout-box"><h3>Basket summary</h3><div class="summary-row"><span>Subtotal</span><strong>${money(subtotal)}</strong></div><div class="summary-row"><span>Delivery</span><strong>${shipping ? money(shipping) : 'Free'}</strong></div><div class="summary-row total"><span>Total</span><strong>${money(total)}</strong></div><a class="btn btn-primary btn-block" href="${href}">${label}</a><p class="small muted" style="margin-top:14px">Static demo checkout. Connect Stripe, Shopify, WooCommerce, or a payment link before taking live payment.</p></div>`; }
  function renderCheckoutSummary(){ const s=$('[data-checkout-summary]'); if(!s) return; const {items,subtotal,shipping,total}=cartTotals(); s.innerHTML = items.length ? summaryHtml(subtotal,shipping,total,'#place-order','Review order') : `<div class="checkout-box"><p>Your basket is empty.</p><a href="shop.html" class="btn btn-primary">Shop now</a></div>`; }
  function checkoutBuyNow(){ const id=new URLSearchParams(location.search).get('buy'); if(id && findProduct(id)){ setCart([{id,qty:1}]); history.replaceState(null,'','checkout.html'); } }
  function bindEvents(){
    updateCartCount();
    $('#menuBtn')?.addEventListener('click',()=>$('#mobilePanel')?.classList.toggle('open'));
    document.addEventListener('click',e=>{ const add=e.target.closest('[data-add]'); if(add){ addToCart(add.dataset.add); } const filter=e.target.closest('[data-filter]'); if(filter){ setFilter(filter.dataset.filter); history.replaceState(null,'', filter.dataset.filter==='all'?'shop.html':`shop.html?category=${filter.dataset.filter}`); }});
    $('#searchProducts')?.addEventListener('input',e=>{ const q=e.target.value.trim().toLowerCase(); $$('.product-card').forEach(card=>{ const catActive=$('.filter-btn.active')?.dataset.filter || 'all'; const catOk=catActive==='all'||card.dataset.category===catActive; const qOk=!q||card.dataset.title.includes(q); card.hidden=!(catOk&&qOk); }); });
    $('#checkoutForm')?.addEventListener('submit',e=>{ e.preventDefault(); const cart=getCart(); if(!cart.length){toast('Add something to the basket first'); return;} const order='MM-'+Date.now().toString().slice(-6); sessionStorage.setItem('mm_order',order); sessionStorage.setItem('mm_order_cart',JSON.stringify(cart)); localStorage.removeItem('mm_cart'); location.href='thank-you.html?order='+order; });
    const orderEl=$('[data-order-number]'); if(orderEl){ orderEl.textContent=new URLSearchParams(location.search).get('order') || sessionStorage.getItem('mm_order') || 'MM-000000'; }
  }
  document.addEventListener('DOMContentLoaded',()=>{ bindEvents(); renderFeatured(); renderShop(); renderProduct(); checkoutBuyNow(); renderCart(); renderCheckoutSummary(); });
})();
